from typing import Annotated

from fastapi import APIRouter, Depends, Query

from app.api.deps import Ctx, require_session
from app.api.errors import ApiError, data_unavailable, invalid_field, not_found, unavailable
from app.api.openapi import errors
from app.data.map_data import MapDataUnavailable
from app.data.route_service import RouteError
from app.models.places import PlaceCandidate
from app.models.routing import RouteRequest, RouteResponse

router = APIRouter(tags=["routing"], dependencies=[Depends(require_session)])


def routing_unavailable() -> ApiError:
    return unavailable(
        "ROUTING_UNAVAILABLE", "La ricerca dei luoghi e dei percorsi non è disponibile"
    )


_STATUS = {"NO_COMPLETED_RUN": 404, "NO_ROUTE": 404, "RUN_NOT_COMPLETED": 409, "SAME_PLACE": 400}


@router.get("/api/places/search", response_model=list[PlaceCandidate], responses=errors(503))
def search_places(
    ctx: Ctx,
    q: Annotated[str, Query(min_length=1, max_length=200, description="Il luogo, a testo")],
) -> list[PlaceCandidate]:
    """Fino a 5 luoghi che corrispondono a `q` (una strada, una piazza, una stazione, una zona, un
    luogo noto, o un incrocio: «via Tasso angolo via Aniello Falcone»), dal più somigliante. Ogni
    candidato ha il nodo stradale da cui un percorso parte o a cui arriva. Solo lettura: nessun
    servizio esterno."""
    if ctx.places is None:
        raise routing_unavailable()
    try:
        return ctx.places.search(q)
    except MapDataUnavailable as exc:
        raise data_unavailable("DATA_UNAVAILABLE", exc) from exc


@router.post("/api/route", response_model=RouteResponse, responses=errors(400, 404, 409, 503))
def compute_route(body: RouteRequest, ctx: Ctx) -> RouteResponse:
    """Il percorso in auto consigliato tra due nodi, con un'alternativa, le chiusure che evita e i
    tratti saturi. Il calcolo è del motore, sui costi dell'ultima iterazione dell'ultima analisi
    completata dell'evento (o di `run_id`), per la fascia che contiene `time`; fuori dalle fasce
    simulate, tempi a strada libera con le sole chiusure. Solo lettura."""
    if ctx.routes is None:
        raise routing_unavailable()
    try:
        return ctx.routes.plan(body)
    except RouteError as exc:
        if exc.field is not None:
            raise invalid_field(exc.field, exc.message, exc.code.lower()) from exc
        if exc.code in ("EVENT_NOT_FOUND", "RUN_NOT_FOUND"):
            raise not_found(exc.message) from exc
        raise ApiError(_STATUS[exc.code], exc.code, exc.message) from exc
    except MapDataUnavailable as exc:
        raise data_unavailable("DATA_UNAVAILABLE", exc) from exc
