import datetime as dt
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, replace

import networkx as nx
import numpy as np

from app.data.resolvers import edge_coordinates, edge_key, edge_point, parse_edge_key
from app.engine import unique
from app.engine.assign import EdgeLoad, Route, Router, assign
from app.engine.background import build_background
from app.engine.demand import build_demand
from app.engine.measures import apply_measures
from app.geo import COORD_DECIMALS, METERS_PER_DEGREE
from app.models.base import WINDOWS, Window
from app.models.config import EngineConfig
from app.models.event import Event
from app.models.operations import OperationRequest
from app.models.run import AttendanceLevel

FREE_FLOW_ASSUMPTION = (
    "nessuna simulazione del traffico per quest'ora: tempi a strada libera (t0 di ogni arco), "
    "considerate solo le strade chiuse"
)


@dataclass(frozen=True, slots=True)
class RoadCosts:
    """I costi per arco su cui si instrada: la rete (con chiusure e misure) e i carichi."""

    graph: nx.MultiDiGraph
    loads: Mapping[str, EdgeLoad]
    assumptions: tuple[str, ...]
    simulated: bool  # i carichi vengono da un'assegnazione (vero) o sono a strada libera (falso)


@dataclass(frozen=True, slots=True)
class PathStep:
    """Archi consecutivi con lo stesso nome, uniti."""

    street_name: str | None
    length_m: float


@dataclass(frozen=True, slots=True)
class ClosureRef:
    label: str
    source_ref: str | None
    edges: tuple[str, ...]


def window_of(event: Event, at: dt.time) -> Window | None:
    """La finestra dell'Evento (arrivo, deflusso) che contiene `at`, o `None`: il motore simula
    solo quelle, e la fine di una finestra è esclusa."""
    for window in WINDOWS:
        span = event.time_window(window)
        if span.start <= at < span.end:
            return window
    return None


def free_flow_loads(graph: nx.MultiDiGraph) -> dict[str, EdgeLoad]:
    """I carichi di una rete senza traffico: ogni arco aperto al suo tempo t0, a v/c zero."""
    loads: dict[str, EdgeLoad] = {}
    for u, v, k, data in graph.edges(keys=True, data=True):
        capacity = float(data["capacity_vph"])
        if capacity <= 0:  # chiuso
            continue
        t0 = float(data["t0_min"])
        loads[edge_key(u, v, k)] = EdgeLoad(
            v_event=0.0,
            v_background=0.0,
            capacity_vph=capacity,
            v_total=0.0,
            vc=0.0,
            t_min=t0,
            cost_min=t0 * float(data.get("perceived_factor", 1.0)),
        )
    return loads


def window_costs(
    base: nx.MultiDiGraph,
    event: Event,
    level: AttendanceLevel,
    window: Window,
    measures: Sequence[OperationRequest],
    config: EngineConfig,
) -> RoadCosts:
    """I costi per arco di `window` con le `measures` in vigore: gli stessi che l'analisi ha avuto.

    Sono i passi di `RoadEngine.run` prima delle metriche (rete con chiusure e misure, traffico di
    fondo, domanda, assegnazione), con le stesse funzioni: stesso input, stesso risultato (un test
    lo confronta con i layer che l'analisi ha salvato). `RoadEngine.run` non restituisce i carichi
    di tutti gli archi, e i layer ne salvano solo una parte e senza i tempi.
    """
    network = apply_measures(base, event, window, measures, config)
    background = build_background(base, event, window, network.closed)
    demand = build_demand(event, level, window, config, base)
    assignment = assign(network.graph, background.volumes, demand.flows, config)
    return RoadCosts(
        graph=network.graph,
        loads=assignment.edges,
        assumptions=unique(*network.assumptions, *assignment.assumptions),
        simulated=True,
    )


def free_flow_costs(base: nx.MultiDiGraph, event: Event, config: EngineConfig) -> RoadCosts:
    """I costi fuori dalle finestre simulate: tempi a strada libera, con le chiusure dell'Evento
    (che non hanno un orario) e nessuna misura (ogni misura vale per una finestra)."""
    network = apply_measures(base, event, WINDOWS[0], (), config)
    return RoadCosts(
        graph=network.graph,
        loads=free_flow_loads(network.graph),
        assumptions=unique(*network.assumptions, FREE_FLOW_ASSUMPTION),
        simulated=False,
    )


def plan_routes(
    graph: nx.MultiDiGraph,
    loads: Mapping[str, EdgeLoad],
    source: int,
    target: int,
    *,
    penalty: float,
    max_longer_pct: float,
    max_overlap_pct: float,
) -> list[Route]:
    """Il percorso a costo minimo e, se c'è, un'alternativa; vuoto se `target` non è raggiungibile.

    L'alternativa è lo stesso calcolo con il costo degli archi del primo moltiplicato per
    `penalty`; si scarta se è lo stesso cammino, se dura più del primo di `max_longer_pct` % o se ne
    ripete più di `max_overlap_pct` % della lunghezza (un cammino che cambia un incrocio non è
    un'alternativa).
    Tempo e lunghezza di ogni percorso sono quelli reali dei suoi archi, non quelli penalizzati.
    """
    first = Router(graph, loads).routes([(source, target)])[(source, target)]
    if first is None:
        return []
    used = set(first.edges)
    penalized = {
        key: replace(load, cost_min=load.cost_min * penalty) if key in used else load
        for key, load in loads.items()
    }
    second = Router(graph, penalized).routes([(source, target)])[(source, target)]
    longest = first.time_min * (1 + max_longer_pct / 100)
    if second is None or second.edges == first.edges or second.time_min > longest:
        return [first]
    shared = sum(
        float(graph.edges[parse_edge_key(key)]["length_m"])
        for key in set(first.edges) & set(second.edges)
    )
    if first.length_m > 0 and shared / first.length_m * 100 > max_overlap_pct:
        return [first]
    return [first, second]


def free_flow_route(graph: nx.MultiDiGraph, source: int, target: int) -> Route | None:
    """Il percorso a strada libera su `graph`, senza altre chiusure di quelle che ha già."""
    return Router(graph, free_flow_loads(graph)).routes([(source, target)])[(source, target)]


def edge_name(graph: nx.MultiDiGraph, key: str) -> str | None:
    name = graph.edges[parse_edge_key(key)].get("name")
    return name if isinstance(name, str) and name.strip() else None


def route_steps(graph: nx.MultiDiGraph, edges: Sequence[str]) -> list[PathStep]:
    """I tratti del percorso: gli archi consecutivi con lo stesso nome, uniti."""
    steps: list[PathStep] = []
    for key in edges:
        name = edge_name(graph, key)
        length = float(graph.edges[parse_edge_key(key)]["length_m"])
        if steps and steps[-1].street_name == name:
            steps[-1] = PathStep(name, steps[-1].length_m + length)
        else:
            steps.append(PathStep(name, length))
    return steps


def route_coordinates(graph: nx.MultiDiGraph, edges: Sequence[str]) -> list[list[float]]:
    """La linea del percorso, `[lon, lat]`: gli archi uno dopo l'altro, senza il punto ripetuto."""
    coordinates: list[list[float]] = []
    for key in edges:
        part = edge_coordinates(graph, parse_edge_key(key), COORD_DECIMALS)
        coordinates.extend(part[1:] if coordinates and coordinates[-1] == part[0] else part)
    return coordinates


def _distances_m(points: np.ndarray, line: Sequence[Sequence[float]]) -> np.ndarray:
    """Per ogni punto `[lon, lat]`, la distanza in metri dalla linea (segmenti, non solo vertici),
    su una proiezione piana locale: esatta a meno di centimetri su una città."""
    path = np.asarray(line, dtype=float)
    lon0, lat0 = path[0]
    scale = np.cos(np.radians(path[:, 1].mean())) * METERS_PER_DEGREE
    ax, ay = (path[:-1, 0] - lon0) * scale, (path[:-1, 1] - lat0) * METERS_PER_DEGREE
    bx, by = (path[1:, 0] - lon0) * scale, (path[1:, 1] - lat0) * METERS_PER_DEGREE
    if len(path) == 1:
        ax = ay = bx = by = np.zeros(1)
    px = ((points[:, 0] - lon0) * scale)[:, None]
    py = ((points[:, 1] - lat0) * METERS_PER_DEGREE)[:, None]
    dx, dy = bx - ax, by - ay
    length_sq = dx * dx + dy * dy
    with np.errstate(divide="ignore", invalid="ignore"):
        t = np.where(length_sq > 0, ((px - ax) * dx + (py - ay) * dy) / length_sq, 0.0)
    t = np.clip(t, 0.0, 1.0)
    return np.asarray(np.hypot(px - (ax + t * dx), py - (ay + t * dy)).min(axis=1))


def _midpoints(graph: nx.MultiDiGraph, keys: Sequence[str]) -> np.ndarray:
    return np.array([edge_point(graph, parse_edge_key(key), 0.5) for key in keys], dtype=float)


def congested_streets(
    graph: nx.MultiDiGraph,
    loads: Mapping[str, EdgeLoad],
    edges: Iterable[str],
    threshold: float,
) -> dict[str, float]:
    """Per ogni strada con un arco in `edges` più carico di `threshold` (v/c), il carico più alto.
    Gli archi senza nome non si elencano: a chi legge non direbbero niente."""
    worst: dict[str, float] = {}
    for key in edges:
        load, name = loads.get(key), edge_name(graph, key)
        if load is not None and name is not None and load.vc > threshold:
            worst[name] = max(worst.get(name, 0.0), load.vc)
    return worst


def congested_near_route(
    graph: nx.MultiDiGraph,
    loads: Mapping[str, EdgeLoad],
    route: Sequence[str],
    threshold: float,
    near_m: float,
) -> dict[str, float]:
    """Come `congested_streets`, ma per gli archi che NON sono sul percorso e hanno il punto medio
    a non più di `near_m` metri dalla sua linea."""
    on_route = set(route)
    candidates = sorted(
        key for key, load in loads.items() if load.vc > threshold and key not in on_route
    )
    if not candidates or not route:
        return {}
    close = _distances_m(_midpoints(graph, candidates), route_coordinates(graph, route)) <= near_m
    return congested_streets(
        graph, loads, (key for key, keep in zip(candidates, close, strict=True) if keep), threshold
    )


def avoided_closures(
    base: nx.MultiDiGraph,
    closures: Sequence[ClosureRef],
    free_path: Route | None,
    route: Route,
    near_m: float,
) -> list[ClosureRef]:
    """Le chiusure vicine (entro `near_m` metri) al percorso a strada libera `free_path` che
    `route` non attraversa. `base` è la rete senza chiusure: serve la geometria."""
    if free_path is None or not free_path.edges:
        return []
    line = route_coordinates(base, free_path.edges)
    used = set(route.edges)
    found: list[ClosureRef] = []
    for closure in closures:
        if not closure.edges or used & set(closure.edges):
            continue
        if (_distances_m(_midpoints(base, closure.edges), line) <= near_m).any():
            found.append(closure)
    return found
