import datetime as dt
from typing import ClassVar, Literal

from pydantic import Field, JsonValue

from app.models.base import ClockTime, FrozenModel, RefId, Slug
from app.models.provenance import Measured
from app.models.yamlconfig import CONFIG_DIR, YamlConfig

RouteWindow = Literal["arrival", "departure", "none"]


class SearchConfig(FrozenModel):
    max_candidates: int = Field(ge=1)
    max_query_words: int = Field(ge=1)
    long_street_m: float = Field(gt=0)
    merge_clusters_m: float = Field(ge=0)
    dedupe_m: float = Field(ge=0)
    crossing_m: float = Field(ge=0)
    fuzzy_cutoff: float = Field(gt=0, le=1)
    intersection_words: list[str] = Field(min_length=1)
    abbreviations: dict[str, str] = Field(default_factory=dict)


class RouteConfig(FrozenModel):
    alternative_penalty: float = Field(gt=1)
    alternative_max_longer_pct: float = Field(ge=0)
    alternative_max_overlap_pct: float = Field(gt=0, le=100)
    congested_max_listed: int = Field(ge=1)
    nearby_m: float = Field(gt=0)
    closure_near_m: float = Field(gt=0)


class RoutingConfig(YamlConfig):
    """`config/routing.yaml`: parametri della ricerca dei luoghi e del calcolo dei percorsi."""

    DEFAULT_PATH: ClassVar = CONFIG_DIR / "routing.yaml"

    search: SearchConfig
    route: RouteConfig


# --- l'API (06 5b) ------------------------------------------------------------------------------


class RouteRequest(FrozenModel):
    event_id: Slug
    from_node: int
    to_node: int
    time: ClockTime
    # l'analisi da usare; omessa, l'ultima completata (`DONE`) dell'evento
    run_id: RefId | None = None


class RouteStep(FrozenModel):
    """Archi consecutivi con lo stesso nome, uniti. `street_name` manca per le strade senza nome."""

    street_name: str | None
    length_m: float = Field(ge=0)


class RouteOption(FrozenModel):
    steps: list[RouteStep]
    duration: Measured  # min
    length: Measured  # km
    geometry: dict[str, JsonValue]  # GeoJSON LineString, [lon, lat]


class AvoidedClosure(FrozenModel):
    label: str
    source_ref: str | None = None


class CongestedStreet(FrozenModel):
    street_name: str
    vc: Measured  # il carico più alto della strada nella fascia


class RouteContext(FrozenModel):
    event: str  # il nome dell'evento
    date: dt.date
    time: dt.time
    window: RouteWindow  # `none`: l'ora è fuori dalle fasce che il motore simula
    peak: dt.time | None  # il picco della fascia simulata, se c'è
    iteration: int = Field(ge=0)
    run_id: RefId


class RouteResponse(FrozenModel):
    """`routes[0]` è il percorso consigliato, `routes[1]` (se c'è) l'alternativa."""

    routes: list[RouteOption] = Field(min_length=1)
    avoided_closures: list[AvoidedClosure]
    congested_on_route: list[CongestedStreet]
    congested_nearby: list[CongestedStreet]
    context: RouteContext
