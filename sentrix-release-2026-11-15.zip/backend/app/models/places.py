from typing import Annotated, ClassVar, Literal, Self

from pydantic import Field, StringConstraints, model_validator

from app.models.base import FrozenModel, Slug
from app.models.geo import GeoPoint
from app.models.yamlconfig import CONFIG_DIR, YamlConfig

PlaceKind = Literal["street", "place", "station", "zone"]

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


class PlaceCandidate(FrozenModel):
    """Un posto che una ricerca propone (06 5b). `lon` e `lat` sono quelli del nodo stradale
    `node_id`, cioè il punto da cui il percorso parte o a cui arriva."""

    id: str = Field(min_length=1)
    label: str = Field(min_length=1)
    kind: PlaceKind
    node_id: int
    lon: float
    lat: float
    score: float = Field(ge=0, le=1)  # 1 = il nome coincide; meno = più approssimato
    long_street: bool = (
        False  # strada estesa oltre `search.long_street_m`: serve un punto più preciso
    )


class KnownPlace(FrozenModel):
    """Una voce di `config/places.yaml`: una zona di `engine.yaml` con altri nomi, o un punto."""

    id: Slug
    label: Text | None = None  # obbligatorio per un punto; per una zona è il suo nome
    zone: Slug | None = None
    lat: float | None = Field(default=None, ge=-90, le=90)
    lon: float | None = Field(default=None, ge=-180, le=180)
    aliases: list[Text] = Field(default_factory=list)

    @model_validator(mode="after")
    def _one_position(self) -> Self:
        has_point = self.lat is not None or self.lon is not None
        if (self.zone is None) == (not has_point):
            raise ValueError(f"{self.id}: serve `zone` oppure `lat` e `lon`, non tutte e due")
        if self.zone is not None and self.label is not None:
            raise ValueError(f"{self.id}: con `zone` il nome è quello della zona: togli `label`")
        if has_point and (self.lat is None or self.lon is None or self.label is None):
            raise ValueError(f"{self.id}: un punto vuole `label`, `lat` e `lon`")
        return self

    @property
    def point(self) -> GeoPoint | None:
        if self.lat is None or self.lon is None:
            return None
        return GeoPoint(lat=self.lat, lon=self.lon)


class PlacesConfig(YamlConfig):
    DEFAULT_PATH: ClassVar = CONFIG_DIR / "places.yaml"

    places: list[KnownPlace] = Field(default_factory=list)

    @model_validator(mode="after")
    def _unique(self) -> Self:
        ids = [place.id for place in self.places]
        if len(set(ids)) != len(ids):
            raise ValueError("id di luogo duplicati")
        return self
