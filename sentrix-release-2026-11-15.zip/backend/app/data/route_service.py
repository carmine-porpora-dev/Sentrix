import logging
import threading
from collections import OrderedDict
from collections.abc import Sequence

import networkx as nx

from app.data.map_data import MapData
from app.data.resolvers import edge_key, resolve_closure
from app.db.repository import Repository
from app.engine.assign import Route
from app.engine.measures import target_edges
from app.engine.routing import (
    ClosureRef,
    RoadCosts,
    avoided_closures,
    congested_near_route,
    congested_streets,
    free_flow_costs,
    free_flow_route,
    plan_routes,
    route_coordinates,
    route_steps,
    window_costs,
    window_of,
)
from app.models.base import Window
from app.models.event import Event
from app.models.operations import ACTIVE_STATES, OperationRequest
from app.models.provenance import Measured, make_measured, measured_id
from app.models.routing import (
    AvoidedClosure,
    CongestedStreet,
    RouteConfig,
    RouteContext,
    RouteOption,
    RouteRequest,
    RouteResponse,
    RouteStep,
)
from app.models.run import Run

logger = logging.getLogger(__name__)

SOURCE = "engine.routing v1"
CITIZEN_NOTICE = "citizen_notice"
CACHE_SIZE = (
    6  # fasce di analisi tenute in memoria: due finestre e la fascia libera, per qualche run
)


class RouteError(Exception):
    """Una richiesta di percorso che non si può soddisfare; `code` è il codice stabile dell'API."""

    def __init__(self, code: str, message: str, field: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.field = field


def measures_in_force(requests: Sequence[OperationRequest]) -> list[OperationRequest]:
    """Le misure in vigore alla fine di un'analisi: accettate, in corso o completate. L'avviso ai
    cittadini non cambia nessun numero (stessa regola dell'orchestratore, che le verifica)."""
    return [r for r in requests if r.state in ACTIVE_STATES and r.type != CITIZEN_NOTICE]


class RouteService:
    def __init__(self, repo: Repository, map_data: MapData, config: RouteConfig) -> None:
        self._repo = repo
        self._map_data = map_data
        self._config = config
        self._cache: OrderedDict[tuple[str, int, str], RoadCosts] = OrderedDict()
        self._lock = threading.Lock()

    # --- l'analisi da usare ---------------------------------------------------------------------

    def _run_and_event(self, request: RouteRequest) -> tuple[Run, Event]:
        if request.run_id is not None:
            run = self._repo.get_run(request.run_id)
            if run is None:
                raise RouteError("RUN_NOT_FOUND", "Analisi non trovata")
            if run.event_id != request.event_id:
                raise RouteError("RUN_OF_OTHER_EVENT", "L'analisi è di un altro evento", "run_id")
            if run.state != "DONE":
                raise RouteError("RUN_NOT_COMPLETED", "L'analisi non è ancora completata")
        else:
            if self._repo.get_event(request.event_id) is None:
                raise RouteError("EVENT_NOT_FOUND", "Evento non trovato")
            done = [r for r in self._repo.list_runs(request.event_id) if r.state == "DONE"]
            if not done:
                raise RouteError("NO_COMPLETED_RUN", "Nessuna analisi completata per questo evento")
            run = done[0]  # il più recente
        event = self._repo.get_event_revision(run.event_id, run.event_revision)
        if event is None:
            raise RouteError("EVENT_NOT_FOUND", "Evento non trovato")
        return run, event

    # --- i costi, in cache ----------------------------------------------------------------------

    def _costs(
        self, run: Run, event: Event, window: Window | None, measures: list[OperationRequest]
    ) -> RoadCosts:
        key = (run.id, run.iteration, window or "none")
        with self._lock:  # una sola assegnazione alla volta: due richieste uguali non la ripetono
            if key in self._cache:
                self._cache.move_to_end(key)
                return self._cache[key]
            base, config = self._map_data.graph(), self._map_data.config
            costs = (
                window_costs(base, event, run.attendance_level, window, measures, config)
                if window is not None
                else free_flow_costs(base, event, config)
            )
            self._cache[key] = costs
            while len(self._cache) > CACHE_SIZE:
                self._cache.popitem(last=False)
            return costs

    # --- il percorso ----------------------------------------------------------------------------

    def plan(self, request: RouteRequest) -> RouteResponse:
        run, event = self._run_and_event(request)
        base = self._map_data.graph()
        for name, node in (("from_node", request.from_node), ("to_node", request.to_node)):
            if node not in base:
                raise RouteError("UNKNOWN_NODE", "Il nodo non è nella rete stradale", name)
        if request.from_node == request.to_node:
            raise RouteError("SAME_PLACE", "Partenza e arrivo coincidono")
        window = window_of(event, request.time)
        measures = measures_in_force(self._repo.list_operation_requests(run.id))
        costs = self._costs(run, event, window, measures)
        routes = plan_routes(
            costs.graph,
            costs.loads,
            request.from_node,
            request.to_node,
            penalty=self._config.alternative_penalty,
            max_longer_pct=self._config.alternative_max_longer_pct,
            max_overlap_pct=self._config.alternative_max_overlap_pct,
        )
        if not routes:
            raise RouteError("NO_ROUTE", "Nessun percorso in auto tra i due punti")
        first = routes[0]
        threshold = self._map_data.config.metrics.vc_critical_threshold
        on_route: dict[str, float] = {}
        nearby: dict[str, float] = {}
        if costs.simulated:
            on_route = congested_streets(costs.graph, costs.loads, first.edges, threshold)
            nearby = congested_near_route(
                costs.graph, costs.loads, first.edges, threshold, self._config.nearby_m
            )
        closures = self._closures(base, event, window, measures)
        avoided = avoided_closures(
            base,
            closures,
            free_flow_route(base, request.from_node, request.to_node),
            first,
            self._config.closure_near_m,
        )
        ids = (
            run.id,
            f"it{run.iteration}",
            window or "none",
            str(request.from_node),
            str(request.to_node),
        )
        return RouteResponse(
            routes=[
                self._option(costs, route, (*ids, role), run, event, request)
                for route, role in zip(routes, ("main", "alt"), strict=False)
            ],
            avoided_closures=[
                AvoidedClosure(label=c.label, source_ref=c.source_ref) for c in avoided
            ],
            congested_on_route=self._streets(on_route, (*ids, "on_route"), costs, run, event),
            congested_nearby=self._streets(
                {n: vc for n, vc in nearby.items() if n not in on_route},
                (*ids, "nearby"),
                costs,
                run,
                event,
            ),
            context=RouteContext(
                event=event.name,
                date=event.date,
                time=request.time,
                window=window or "none",
                peak=event.time_window(window).peak if window else None,
                iteration=run.iteration,
                run_id=run.id,
            ),
        )

    # --- le parti della risposta ----------------------------------------------------------------

    def _closures(
        self,
        base: nx.MultiDiGraph,
        event: Event,
        window: Window | None,
        measures: Sequence[OperationRequest],
    ) -> list[ClosureRef]:
        """Le chiusure in vigore: quelle dell'Evento e, nella finestra simulata, le `close_road`
        accettate (ogni misura vale per una finestra, fuori dalle finestre non ce n'è nessuna)."""
        found = [
            ClosureRef(c.label, c.source_ref, tuple(resolve_closure(c, base)))
            for c in event.closures
            if c.mode == "closed"
        ]
        for request in measures:
            if request.type == "close_road" and window is not None and request.window == window:
                keys = tuple(edge_key(*key) for key in target_edges(request, base))
                found.append(ClosureRef(request.target_label, f"misura {request.action_id}", keys))
        return found

    def _measured(
        self,
        parts: Sequence[str],
        value: float,
        unit: str,
        method: str,
        costs: RoadCosts,
        run: Run,
        event: Event,
        request: RouteRequest | None,
    ) -> Measured:
        inputs = [
            f"analisi {run.id} iterazione {run.iteration}",
            f"evento {event.id} revisione {run.event_revision}",
            f"fascia {parts[2]}",
        ]
        if request is not None:
            inputs.append(f"da nodo {request.from_node} a nodo {request.to_node}")
        return make_measured(
            id=measured_id(*parts),
            value=value,
            unit=unit,
            kind="simulated" if costs.simulated else "estimate",
            source=SOURCE,
            method=method,
            inputs=inputs,
            assumptions=list(costs.assumptions),
            as_of=run.ended_at,
        )

    def _option(
        self,
        costs: RoadCosts,
        route: Route,
        parts: Sequence[str],
        run: Run,
        event: Event,
        request: RouteRequest,
    ) -> RouteOption:
        how = (
            "somma dei tempi BPR degli archi del cammino a costo minimo, con i carichi "
            "dell'ultima iterazione"
            if costs.simulated
            else "somma dei tempi a strada libera degli archi del cammino a costo minimo"
        )
        return RouteOption(
            steps=[
                RouteStep(street_name=s.street_name, length_m=round(s.length_m, 1))
                for s in route_steps(costs.graph, route.edges)
            ],
            duration=self._measured(
                (*parts, "duration"),
                round(route.time_min, 1),
                "min",
                how,
                costs,
                run,
                event,
                request,
            ),
            length=self._measured(
                (*parts, "length"),
                round(route.length_m / 1000, 2),
                "km",
                "somma delle lunghezze OSM degli archi del cammino scelto",
                costs,
                run,
                event,
                request,
            ),
            geometry={
                "type": "LineString",
                "coordinates": route_coordinates(costs.graph, route.edges),
            },
        )

    def _streets(
        self,
        worst: dict[str, float],
        parts: Sequence[str],
        costs: RoadCosts,
        run: Run,
        event: Event,
    ) -> list[CongestedStreet]:
        ranked = sorted(worst.items(), key=lambda item: (-item[1], item[0]))
        return [
            CongestedStreet(
                street_name=name,
                vc=self._measured(
                    (*parts, str(rank), "vc"),
                    round(vc, 2),
                    "rapporto",
                    "carico (traffico di fondo + evento) diviso la capacità, sull'arco più carico "
                    "della strada",
                    costs,
                    run,
                    event,
                    None,
                ),
            )
            for rank, (name, vc) in enumerate(ranked[: self._config.congested_max_listed], start=1)
        ]
