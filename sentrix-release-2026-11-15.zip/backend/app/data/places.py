import difflib
import logging
import re
import threading
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import get_args

import networkx as nx
import numpy as np

from app.data.gtfs import GtfsFeed, RouteClasses
from app.data.map_data import MapData, MapDataUnavailable
from app.data.resolvers import normalize_name, osm_name_parts
from app.geo import haversine_m
from app.models.config import EngineConfig, RailKind
from app.models.demand import Zone
from app.models.places import PlaceCandidate, PlaceKind, PlacesConfig
from app.models.routing import SearchConfig

logger = logging.getLogger(__name__)

# a parità di punteggio, il luogo noto vince sulla stazione, sulla zona e sulla strada
KIND_RANK: dict[PlaceKind, int] = {"place": 0, "station": 1, "zone": 2, "street": 3}
EXACT = 1.0
WORDS_BASE, WORDS_SPAN = 0.5, 0.45  # tutte le parole della ricerca nel nome: da 0,5 a 0,95
FUZZY_SPAN = 0.45  # ricerca approssimata: al massimo 0,45
_LABEL_PARTS = re.compile(r"\s*(?:/|,|—|–)\s*")
RAIL_CLASSES: tuple[RailKind, ...] = get_args(RailKind)


@dataclass(frozen=True, slots=True)
class Station:
    """Una stazione di metro o funicolare: le banchine con lo stesso nome sono una stazione sola."""

    name: str
    rail_class: str
    lat: float
    lon: float


@dataclass(frozen=True, slots=True)
class Entry:
    """Un luogo del dizionario, già agganciato a un nodo della rete."""

    id: str
    label: str
    kind: PlaceKind
    node: int
    names: tuple[str, ...]  # i nomi con cui lo si cerca, normalizzati
    base_name: str  # il nome senza il suffisso che distingue i pezzi di una strada
    nodes: frozenset[int] = frozenset()  # per una strada, i suoi nodi (servono agli incroci)
    long_street: bool = False
    extent_m: float = 0.0
    order: int = 0  # a parità di tutto, chi viene prima (la metro prima della funicolare)
    group: str | None = (
        None  # chi ha lo stesso gruppo è lo stesso posto (stazioni con lo stesso nome)
    )


# --- le stazioni del feed -------------------------------------------------------------------------


def rail_stations(feed: GtfsFeed, classes: RouteClasses) -> list[Station]:
    """Le stazioni di Linea 1, Linea 6 e funicolari: le fermate delle loro corse. Le banchine con lo
    stesso nome nella stessa classe sono una stazione sola, nel loro punto medio."""
    stops = feed.stops.assign(stop_id=feed.stops["stop_id"].astype(str)).set_index("stop_id")
    found: dict[tuple[str, str], list[tuple[str, float, float]]] = defaultdict(list)
    for rail_class in RAIL_CLASSES:
        routes = classes.by_class.get(rail_class, frozenset())
        trips = feed.trips[feed.trips["route_id"].astype(str).isin(routes)]["trip_id"]
        stop_ids = feed.stop_times[feed.stop_times["trip_id"].isin(trips)]["stop_id"].astype(str)
        for stop_id in sorted(stop_ids.unique()):
            if stop_id in stops.index:
                row = stops.loc[stop_id]
                name = str(row["stop_name"]).strip()
                found[(rail_class, normalize_name(name))].append(
                    (name, float(row["stop_lat"]), float(row["stop_lon"]))
                )
    return [
        Station(
            name=min(name for name, _, _ in group),
            rail_class=rail_class,
            lat=float(np.mean([lat for _, lat, _ in group])),
            lon=float(np.mean([lon for _, _, lon in group])),
        )
        for (rail_class, _), group in sorted(found.items())
    ]


# --- la costruzione -------------------------------------------------------------------------------


def _label_names(label: str) -> list[str]:
    """Il nome intero e le sue parti («Porto / Molo Beverello» vale anche «Porto» e «Molo
    Beverello»), normalizzati e senza doppioni."""
    parts = [label, *_LABEL_PARTS.split(label)]
    return list(dict.fromkeys(n for n in (normalize_name(p) for p in parts) if n))


def _latlon(graph: nx.MultiDiGraph, node: int) -> tuple[float, float]:
    return float(graph.nodes[node]["y"]), float(graph.nodes[node]["x"])


def _extent_m(graph: nx.MultiDiGraph, nodes: Iterable[int]) -> float:
    """La diagonale del rettangolo che contiene i nodi, in metri."""
    points = [_latlon(graph, n) for n in nodes]
    lats, lons = [p[0] for p in points], [p[1] for p in points]
    return float(haversine_m(min(lats), min(lons), (max(lats), max(lons))))


def _closest_m(graph: nx.MultiDiGraph, a: Iterable[int], b: Iterable[int]) -> float:
    """La distanza minima tra due insiemi di nodi, in metri."""
    lats = np.array([_latlon(graph, n)[0] for n in b])
    lons = np.array([_latlon(graph, n)[1] for n in b])
    return float(min(haversine_m(lats, lons, _latlon(graph, n)).min() for n in a))


def _pieces(
    graph: nx.MultiDiGraph, edges: Sequence[tuple[int, int, int]], merge_m: float
) -> list[frozenset[int]]:
    """I pezzi di una strada: gli archi collegati tra loro, poi i pezzi più vicini di `merge_m`
    metri riuniti (le due carreggiate di una piazza non sono due luoghi)."""
    graph_of_name: nx.Graph = nx.Graph()
    graph_of_name.add_edges_from((u, v) for u, v, _ in edges)
    pieces = [frozenset(c) for c in nx.connected_components(graph_of_name)]
    pieces.sort(key=min)
    merged = True
    while merged and len(pieces) > 1:
        merged = False
        for i, first in enumerate(pieces):
            for j in range(i + 1, len(pieces)):
                if _closest_m(graph, first, pieces[j]) < merge_m:
                    pieces[i] = first | pieces[j]
                    del pieces[j]
                    merged = True
                    break
            if merged:
                break
    return sorted(pieces, key=min)


class _Snapper:
    """Il nodo più vicino a un punto tra quelli della componente connessa principale: da un nodo
    di un pezzo isolato della rete non si va da nessuna parte."""

    def __init__(self, graph: nx.MultiDiGraph, nodes: Iterable[int], max_distance_m: float) -> None:
        self.ids = np.array(sorted(nodes), dtype=np.int64)
        self.lats = np.array([_latlon(graph, int(n))[0] for n in self.ids])
        self.lons = np.array([_latlon(graph, int(n))[1] for n in self.ids])
        self.max_distance_m = max_distance_m

    def node(self, lat: float, lon: float) -> int | None:
        distances = haversine_m(self.lats, self.lons, (lat, lon))
        best = int(np.argmin(distances))
        return int(self.ids[best]) if distances[best] <= self.max_distance_m else None


def _street_entries(
    graph: nx.MultiDiGraph, main: frozenset[int], search: SearchConfig
) -> list[Entry]:
    by_name: dict[str, list[tuple[int, int, int]]] = defaultdict(list)
    spellings: dict[str, Counter[str]] = defaultdict(Counter)
    crossing: dict[int, set[str]] = defaultdict(set)  # per nodo, le strade che ci passano
    for u, v, k, data in graph.edges(keys=True, data=True):
        for part in osm_name_parts(data.get("name")):
            normalized = normalize_name(part)
            if normalized:
                by_name[normalized].append((u, v, k))
                spellings[normalized][part] += 1
                crossing[u].add(normalized)
                crossing[v].add(normalized)
    # come si scrive: l'ortografia più frequente (a parità, la prima in ordine alfabetico)
    shown = {
        name: min(counts.items(), key=lambda item: (-item[1], item[0]))[0]
        for name, counts in spellings.items()
    }
    entries: list[Entry] = []
    for normalized in sorted(by_name):
        pieces = [
            p for p in _pieces(graph, by_name[normalized], search.merge_clusters_m) if p & main
        ]
        pieces.sort(key=lambda nodes: (-_extent_m(graph, nodes), min(nodes)))
        for index, nodes in enumerate(pieces, start=1):
            usable = sorted(nodes & main)
            lats = np.array([_latlon(graph, n)[0] for n in usable])
            lons = np.array([_latlon(graph, n)[1] for n in usable])
            center = usable[int(np.argmin(haversine_m(lats, lons, (lats.mean(), lons.mean()))))]
            label = shown[normalized]
            if len(pieces) > 1:  # lo stesso nome in più posti: dice dove, con un incrocio
                others = sorted(crossing[center] - {normalized})
                label += f" (presso {shown[others[0]]})" if others else f" (n. {index})"
            entries.append(
                Entry(
                    id=f"street:{normalized.lower().replace(' ', '-')}:{index}",
                    label=label,
                    kind="street",
                    node=center,
                    names=(normalized,),
                    base_name=shown[normalized],
                    nodes=frozenset(usable),
                    long_street=_extent_m(graph, nodes) > search.long_street_m,
                    extent_m=_extent_m(graph, nodes),
                )
            )
    return entries


def build_entries(
    graph: nx.MultiDiGraph,
    config: EngineConfig,
    known: PlacesConfig | None,
    stations: Sequence[Station],
    class_labels: Mapping[str, str],
    search: SearchConfig,
) -> list[Entry]:
    """Tutti i luoghi: strade della rete, zone e punti di `engine.yaml`, stazioni, luoghi noti. Un
    luogo che non si aggancia alla rete (oltre `node_snap_max_distance_m`) si salta, e si dice."""
    components = [frozenset(c) for c in nx.strongly_connected_components(graph)]
    main = max(components, key=len)
    snapper = _Snapper(graph, main, config.node_snap_max_distance_m)
    entries = _street_entries(graph, main, search)

    def add(
        entry_id: str,
        label: str,
        kind: PlaceKind,
        lat: float,
        lon: float,
        names: Iterable[str],
        order: int = 0,
        group: str | None = None,
    ) -> None:
        node = snapper.node(lat, lon)
        if node is None:
            logger.warning(
                "Luogo «%s» oltre %g m dalla rete: saltato", label, snapper.max_distance_m
            )
            return
        entries.append(
            Entry(
                id=entry_id,
                label=label,
                kind=kind,
                node=node,
                names=tuple(dict.fromkeys(names)),
                base_name=label,
                order=order,
                group=group,
            )
        )

    zones: dict[str, Zone] = {zone.id: zone for zone in config.demand.zones}
    for zone in zones.values():
        add(f"zone:{zone.id}", zone.name, "zone", zone.centroid.lat, zone.centroid.lon,
            _label_names(zone.name))  # fmt: skip
    labelled = [d.point for d in config.demand.car_destinations]
    for pair in config.demand.od_pairs:
        labelled += [end.point for end in (pair.origin, pair.destination) if end.point]
    seen: set[tuple[float, float, str]] = set()
    for point in labelled:
        key = (point.lat, point.lon, point.label or "")
        if point.label and key not in seen:
            seen.add(key)
            add(f"point:{len(seen)}", point.label, "place", point.lat, point.lon,
                _label_names(point.label))  # fmt: skip
    for place in known.places if known else ():
        aliases = [n for n in (normalize_name(a) for a in place.aliases) if n]
        if place.zone is not None:
            linked = zones.get(place.zone)
            if linked is None:
                logger.warning(
                    "Luogo «%s»: la zona «%s» non c'è in engine.yaml", place.id, place.zone
                )
                continue
            add(f"place:{place.id}", linked.name, "place", linked.centroid.lat, linked.centroid.lon,
                [*_label_names(linked.name), *aliases])  # fmt: skip
        elif place.label is not None and place.lat is not None and place.lon is not None:
            add(f"place:{place.id}", place.label, "place", place.lat, place.lon,
                [*_label_names(place.label), *aliases])  # fmt: skip
    counts: Counter[str] = Counter()
    for station in stations:
        counts[station.rail_class] += 1
        suffix = class_labels.get(station.rail_class, station.rail_class)
        add(f"station:{station.rail_class}:{counts[station.rail_class]}",
            f"{station.name.title()} ({suffix})", "station", station.lat, station.lon,
            _label_names(station.name), RAIL_CLASSES.index(station.rail_class),
            normalize_name(station.name))  # fmt: skip
    return entries


# --- la ricerca -----------------------------------------------------------------------------------


def _expand(text: str, abbreviations: Mapping[str, str]) -> str:
    """Espande le abbreviazioni («v.le Gramsci» → «viale gramsci»), una parola alla volta."""
    return " ".join(abbreviations.get(word, word) for word in text.lower().split())


class PlaceIndex:
    def __init__(
        self, entries: Sequence[Entry], search: SearchConfig, graph: nx.MultiDiGraph
    ) -> None:
        self._entries = list(entries)
        self._search = search
        self._graph = graph
        self._words = [tuple(frozenset(n.split()) for n in e.names) for e in self._entries]

    def __len__(self) -> int:
        return len(self._entries)

    def entries(self) -> list[Entry]:
        return list(self._entries)

    def search(self, query: str) -> list[PlaceCandidate]:
        """Fino a `max_candidates` luoghi, dal più somigliante. Prima un incrocio («A angolo B»),
        poi per nome intero e per parole e, solo se non c'è altro, per somiglianza."""
        text = _expand(query, self._search.abbreviations)
        return self._candidates(self._crossings(text) or self._score(normalize_name(text)))

    def _score(self, wanted: str) -> list[tuple[float, Entry]]:
        words = frozenset(wanted.split())
        if not words or len(words) > self._search.max_query_words:
            return []
        hits: list[tuple[float, Entry]] = []
        for entry, name_words in zip(self._entries, self._words, strict=True):
            best = 0.0
            for name, in_name in zip(entry.names, name_words, strict=True):
                if name == wanted:
                    best = EXACT
                    break
                if words <= in_name:
                    best = max(best, WORDS_BASE + WORDS_SPAN * len(words) / len(in_name))
            if best:
                hits.append((best, entry))
        return hits or self._fuzzy(wanted)

    def _fuzzy(self, wanted: str) -> list[tuple[float, Entry]]:
        """Per somiglianza, parola per parola: ogni parola cercata deve somigliare (almeno
        `fuzzy_cutoff`) a una parola del nome. Cattura gli errori di battitura («plebicito»)."""
        cutoff = self._search.fuzzy_cutoff
        asked = wanted.split()
        hits: list[tuple[float, Entry]] = []
        for entry, name_words in zip(self._entries, self._words, strict=True):
            best = 0.0
            for in_name in name_words:
                closest = [self._closest(word, in_name, cutoff) for word in asked]
                if min(closest) >= cutoff:
                    best = max(best, sum(closest) / len(closest))
            if best:
                hits.append((FUZZY_SPAN * best, entry))
        return hits

    @staticmethod
    def _closest(word: str, candidates: frozenset[str], cutoff: float) -> float:
        """La somiglianza (0-1) di `word` con la parola più simile di `candidates`; 0 per quelle
        che, date le lunghezze, non possono arrivare a `cutoff` (non si confrontano nemmeno)."""
        best = 0.0
        for other in candidates:
            if 2 * min(len(word), len(other)) / (len(word) + len(other)) < cutoff:
                continue
            matcher = difflib.SequenceMatcher(None, word, other)
            if matcher.real_quick_ratio() > best and matcher.quick_ratio() > best:
                best = max(best, matcher.ratio())
        return best

    def _crossings(self, text: str) -> list[tuple[float, Entry]]:
        """«via Tasso angolo via Aniello Falcone»: dove le due strade si incontrano, cioè un nodo
        comune o, se OSM le modella con nodi diversi, i due più vicini (entro `crossing_m`)."""
        words = "|".join(re.escape(w) for w in self._search.intersection_words)
        sides = re.split(rf"\s+(?:{words})\s+|\s*/\s*", text, maxsplit=1)
        if len(sides) != 2:
            return []
        first, second = (self._streets(side) for side in sides)
        found: dict[int, tuple[float, Entry]] = {}
        for score_a, a in first:
            for score_b, b in second:
                if a.base_name == b.base_name:
                    continue
                distance, node = self._nearest_pair(a.nodes, b.nodes)
                if distance > self._search.crossing_m:
                    continue
                score = min(score_a, score_b)
                if node not in found or score > found[node][0]:
                    name = f"{a.base_name} / {b.base_name}"
                    found[node] = (
                        score,
                        Entry(id=f"crossing:{node}", label=name, kind="street", node=node,
                              names=(), base_name=name),
                    )  # fmt: skip
        return list(found.values())

    def _streets(self, side: str) -> list[tuple[float, Entry]]:
        """Le strade che corrispondono a un lato di un incrocio, le migliori prime."""
        hits = [(s, e) for s, e in self._score(normalize_name(side)) if e.kind == "street"]
        hits.sort(key=lambda item: (-item[0], -item[1].extent_m, item[1].id))
        return hits[: self._search.max_candidates]

    def _nearest_pair(self, a: frozenset[int], b: frozenset[int]) -> tuple[float, int]:
        """La distanza in metri tra i due nodi più vicini (uno per strada) e quello di `a`: zero e
        il nodo comune più basso se le strade ne hanno uno."""
        lats = np.array([_latlon(self._graph, n)[0] for n in sorted(b)])
        lons = np.array([_latlon(self._graph, n)[1] for n in sorted(b)])
        return min(
            (float(haversine_m(lats, lons, _latlon(self._graph, n)).min()), n) for n in sorted(a)
        )

    def _candidates(self, scored: Sequence[tuple[float, Entry]]) -> list[PlaceCandidate]:
        ranked = sorted(
            scored,
            key=lambda item: (
                -item[0], KIND_RANK[item[1].kind], item[1].order, -item[1].extent_m,
                item[1].label, item[1].id,
            ),
        )  # fmt: skip
        kept: list[tuple[float, Entry]] = []
        for score, entry in ranked:
            lat, lon = _latlon(self._graph, entry.node)
            if any(
                entry.node == other.node
                or (entry.group is not None and entry.group == other.group)
                or haversine_m(lat, lon, _latlon(self._graph, other.node)) < self._search.dedupe_m
                for _, other in kept
            ):
                continue
            kept.append((score, entry))
            if len(kept) == self._search.max_candidates:
                break
        return [
            PlaceCandidate(
                id=entry.id,
                label=entry.label,
                kind=entry.kind,
                node_id=entry.node,
                lon=_latlon(self._graph, entry.node)[1],
                lat=_latlon(self._graph, entry.node)[0],
                score=round(score, 2),
                long_street=entry.long_street,
            )
            for score, entry in kept
        ]


class PlaceDirectory:
    """Il dizionario dei luoghi, costruito al primo uso (la rete e il feed si caricano allora, non
    all'avvio: un'istanza senza i dati parte lo stesso)."""

    def __init__(
        self,
        map_data: MapData,
        known: PlacesConfig,
        search: SearchConfig,
        class_labels: Mapping[str, str],
    ) -> None:
        self._map_data = map_data
        self._known = known
        self._search = search
        self._class_labels = class_labels
        self._index: PlaceIndex | None = None
        self._lock = threading.Lock()

    def index(self) -> PlaceIndex:
        """`MapDataUnavailable` se manca la rete stradale; senza il feed GTFS, niente stazioni."""
        with self._lock:
            if self._index is None:
                graph = self._map_data.graph()
                try:
                    stations = rail_stations(self._map_data.feed(), self._map_data.route_classes())
                except MapDataUnavailable:
                    logger.warning("Feed GTFS non disponibile: il dizionario non ha le stazioni")
                    stations = []
                entries = build_entries(
                    graph,
                    self._map_data.config,
                    self._known,
                    stations,
                    self._class_labels,
                    self._search,
                )
                self._index = PlaceIndex(entries, self._search, graph)
            return self._index

    def search(self, query: str) -> list[PlaceCandidate]:
        return self.index().search(query)
