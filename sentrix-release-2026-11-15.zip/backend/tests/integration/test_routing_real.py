import json
import re
import time
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import networkx as nx
import pytest
from fastapi.testclient import TestClient

from app.data.gtfs import load_feed
from app.data.map_data import MapData
from app.data.paths import DataPaths, default_data_dir
from app.data.route_service import measures_in_force
from app.db.repository import Repository
from app.engine.routing import window_costs
from app.engine.run import RoadEngine
from app.engine.transit import TransitNetwork
from app.engine.transit_run import TransitEngine
from app.llm.cache import DEFAULT_DEMO_CACHE_DIR, read_demo_file
from app.main import create_app
from app.models.agents_config import AgentsConfig
from app.models.base import WINDOWS
from app.models.config import EngineConfig
from app.models.event import Event
from app.models.places import PlacesConfig
from app.models.run import Run
from app.orchestrator.engines import RealEngines
from app.settings import Settings
from scripts import route_check
from tests.conftest import PASSWORD, SESSION_SECRET, log_in
from tests.integration.conftest import FEED_PATH
from tests.support import graph_fingerprint

pytestmark = pytest.mark.realdata

EVENT = "regate_sep_2026"
MAX_SECONDS = 90
COLD_SECONDS = 10.0  # la prima richiesta di una fascia: ~0,4 s sulla macchina di sviluppo
WARM_SECONDS = 2.0


@dataclass
class Analysis:
    client: TestClient
    repo: Repository
    run: Run
    event: Event
    graph: nx.MultiDiGraph
    data_dir: Path


@pytest.fixture(scope="module")
def analysis(
    tmp_path_factory: pytest.TempPathFactory,
    road_graph: nx.MultiDiGraph,
    transit_network: TransitNetwork,
    road_config: EngineConfig,
) -> Iterator[Analysis]:
    """Un'analisi vera di Regate (`cache_only`, dati veri) e un'app che sa dove sta la rete."""
    labels = AgentsConfig.from_yaml().labels.route_classes
    engines = RealEngines(
        road_graph,
        RoadEngine(road_graph, road_config),
        TransitEngine(transit_network, road_config),
        transit_network,
        road_config,
        labels,
    )
    data_dir = tmp_path_factory.mktemp("assistant") / "data"
    settings = Settings(
        env="local",
        data_dir=data_dir,
        app_password=PASSWORD,
        session_secret=SESSION_SECRET,
        llm_mode="cache_only",
        gemini_model=read_demo_file(DEFAULT_DEMO_CACHE_DIR / f"{EVENT}.json").model,
    )
    map_data = MapData(
        DataPaths(default_data_dir()),
        graph=road_graph,
        feed=load_feed(FEED_PATH),
        config=road_config,
    )
    app = create_app(settings, engines=engines, map_data=map_data)
    with TestClient(app) as client:
        log_in(client)
        body = {"event_id": EVENT, "attendance_level": "mid", "manual_response": False}
        run_id = client.post("/api/runs", json=body).json()["run_id"]
        started = time.perf_counter()
        while time.perf_counter() - started < MAX_SECONDS:
            if client.get(f"/api/runs/{run_id}").json()["run"]["state"] in ("DONE", "ERROR"):
                break
            time.sleep(0.25)
        repo = Repository(data_dir / "napoli.db")
        run = repo.get_run(run_id)
        assert run is not None and run.state == "DONE", run
        event = repo.get_event_revision(run.event_id, run.event_revision)
        assert event is not None
        yield Analysis(client, repo, run, event, road_graph, data_dir)


# --- i costi ricalcolati sono quelli dell'analisi ----------------------------------------------


@pytest.mark.parametrize("window", WINDOWS)
def test_i_costi_ricalcolati_coincidono_con_i_layer_che_l_analisi_ha_salvato(
    analysis: Analysis, road_config: EngineConfig, window: str
) -> None:
    """L'ipotesi di 10 §4.2: il ricalcolo è deterministico, stesso risultato dell'analisi. Si
    confronta con il layer `edges_vc` dell'ultima iterazione: ogni arco salvato ha lo stesso v/c
    e gli archi salvati sono esattamente quelli che il layer sceglie di salvare."""
    run, event = analysis.run, analysis.event
    measures = measures_in_force(analysis.repo.list_operation_requests(run.id))
    costs = window_costs(analysis.graph, event, run.attendance_level, window, measures, road_config)  # type: ignore[arg-type]
    layer = analysis.repo.get_layer(run.id, run.iteration, "edges_vc")
    assert layer is not None
    stored = {
        str(f.properties["edge_key"]): float(f.properties["vc"])  # type: ignore[arg-type]
        for f in layer.features
        if f.properties["window"] == window and not f.properties["closed"]
    }
    assert len(stored) > 100  # un'analisi vera ha centinaia di archi carichi
    for edge, vc in stored.items():
        assert costs.loads[edge].vc == vc, edge
    first_class = road_config.metrics.vc_classes[0]
    saved_by_the_engine = {
        edge for edge, load in costs.loads.items() if load.vc >= first_class or load.v_event > 0
    }
    assert set(stored) == saved_by_the_engine  # non uno in più né uno in meno


def test_le_misure_in_vigore_sono_quelle_dell_ultima_iterazione(analysis: Analysis) -> None:
    in_force = measures_in_force(analysis.repo.list_operation_requests(analysis.run.id))
    assert in_force, "un'analisi vera ha delle misure approvate"
    assert all(r.state in ("ACCEPTED", "IN_PROGRESS", "COMPLETED") for r in in_force)
    assert all(r.type != "citizen_notice" for r in in_force)


# --- il dizionario sui dati veri ---------------------------------------------------------------


def search(analysis: Analysis, text: str) -> list[dict[str, Any]]:
    response = analysis.client.get("/api/places/search", params={"q": text})
    assert response.status_code == 200, response.text
    return list(response.json())


def test_ogni_luogo_di_places_yaml_si_aggancia_alla_rete(analysis: Analysis) -> None:
    """Un luogo che non si aggancia si salta in silenzio (con un avviso nel log): qui si vede."""
    for place in PlacesConfig.from_yaml().places:
        alias = place.aliases[0]
        ids = {c["id"] for c in search(analysis, alias)}
        assert f"place:{place.id}" in ids, f"{place.id}: «{alias}» non si trova"


@pytest.mark.parametrize(
    ("text", "label", "kind"),
    [
        ("piazza Garibaldi", "Piazza Garibaldi", "place"),
        ("stazione Centrale", "Stazione Centrale / Garibaldi", "place"),
        ("Napoli Centrale", "Stazione Centrale / Garibaldi", "place"),
        ("Molo Beverello", "Porto / Molo Beverello", "place"),
        ("Stazione Marittima", "Porto / Molo Beverello", "place"),
        ("Fuorigrotta", "Fuorigrotta", "zone"),
        ("Stadio Maradona", "Stadio Maradona", "place"),
        ("Castel dell'Ovo", "Castel dell'Ovo", "place"),
        ("piazza Plebiscito", "Piazza del Plebiscito", "street"),
        ("Mergellina", "Mergellina (Linea 6 della metropolitana)", "station"),
        ("plebicito", "Piazza del Plebiscito", "street"),  # il refuso
        (
            "via Tasso angolo via Aniello Falcone",
            "Via Torquato Tasso / Via Aniello Falcone",
            "street",
        ),
    ],
)
def test_i_luoghi_delle_domande_di_verifica_si_risolvono(
    analysis: Analysis, text: str, label: str, kind: str
) -> None:
    top = search(analysis, text)[0]
    assert (top["label"], top["kind"]) == (label, kind)
    assert top["node_id"] in analysis.graph.nodes


def test_via_tasso_e_una_strada_lunga_e_mergellina_e_un_posto_solo(analysis: Analysis) -> None:
    tasso = search(analysis, "via Tasso")[0]
    assert tasso["label"] == "Via Torquato Tasso" and tasso["long_street"] is True
    stations = [c for c in search(analysis, "Mergellina") if c["kind"] == "station"]
    assert len(stations) == 1  # la stazione della Linea 6 e la funicolare sono lo stesso posto


def test_le_stazioni_del_feed_ci_sono_e_nessuna_e_di_un_altra_citta(analysis: Analysis) -> None:
    """Le fermate GTFS «MARITTIMA» sono a Torre Annunziata: per nome non si deve prendere niente."""
    for text in ("Dante", "Museo", "Garibaldi", "Vanvitelli"):
        assert any(c["kind"] == "station" or text in c["label"] for c in search(analysis, text))
    for candidate in search(analysis, "Marittima"):
        assert abs(candidate["lat"] - 40.83) < 0.05 and abs(candidate["lon"] - 14.25) < 0.1


# --- le domande di verifica del cancello A1 ----------------------------------------------------


def node_of(analysis: Analysis, text: str) -> int:
    return int(search(analysis, text)[0]["node_id"])


def ask(analysis: Analysis, start: str, end: str, at: str) -> dict[str, Any]:
    body = {
        "event_id": EVENT,
        "from_node": node_of(analysis, start),
        "to_node": node_of(analysis, end),
        "time": at,
    }
    response = analysis.client.post("/api/route", json=body)
    assert response.status_code == 200, response.text
    return dict(response.json())


CLOSURES = [
    "Via Francesco Caracciolo (viale Dohrn – piazza Vittoria)",
    "Viale Anton Dohrn",
]


@pytest.mark.parametrize(
    ("start", "end", "at", "window", "kind"),
    [
        ("piazza Garibaldi", "via Tasso", "13:30", "arrival", "simulated"),  # domanda 1
        ("stazione Centrale", "Mergellina", "16:45", "departure", "simulated"),  # 2
        ("Molo Beverello", "Fuorigrotta", "13:45", "arrival", "simulated"),  # 6
        ("piazza Plebiscito", "Vomero", "10:00", "none", "estimate"),  # 7: fuori fascia
    ],
)
def test_le_domande_di_verifica_danno_percorsi_sensati(
    analysis: Analysis, start: str, end: str, at: str, window: str, kind: str
) -> None:
    data = ask(analysis, start, end, at)
    context = data["context"]
    assert (context["window"], context["run_id"]) == (window, analysis.run.id)
    assert (
        context["iteration"] == analysis.run.iteration and context["event"] == analysis.event.name
    )
    main = data["routes"][0]
    assert main["steps"] and main["duration"]["kind"] == kind
    assert (
        1 < main["duration"]["value"] < 60
    )  # minuti: da un quartiere all'altro, non secondi né ore
    assert 0.5 < main["length"]["value"] < 30
    assert sum(s["length_m"] for s in main["steps"]) == pytest.approx(
        main["length"]["value"] * 1000, abs=60
    )  # i passi sommano alla lunghezza (arrotondata a 10 m)
    # la linea parte dal nodo di partenza e arriva a quello di arrivo
    graph = analysis.graph
    first, last = main["geometry"]["coordinates"][0], main["geometry"]["coordinates"][-1]
    for point, text in ((first, start), (last, end)):
        node = graph.nodes[node_of(analysis, text)]
        assert point == pytest.approx([node["x"], node["y"]], abs=2e-6)
    for alternative in data["routes"][1:]:
        assert alternative["duration"]["value"] >= main["duration"]["value"]


def test_le_chiusure_della_regata_si_evitano_dove_il_percorso_normale_ci_passerebbe(
    analysis: Analysis,
) -> None:
    for start, end, at in (
        ("stazione Centrale", "Mergellina", "16:45"),
        ("Molo Beverello", "Fuorigrotta", "13:45"),
    ):
        data = ask(analysis, start, end, at)
        assert [c["label"] for c in data["avoided_closures"]] == CLOSURES
        assert all(c["source_ref"] for c in data["avoided_closures"])
        names = {s["street_name"] or "" for r in data["routes"] for s in r["steps"]}
        assert not any("Caracciolo" in n or "Dohrn" in n for n in names)  # davvero non ci passa
    near = ask(analysis, "piazza Plebiscito", "Vomero", "10:00")
    assert near["avoided_closures"] == [] and near["congested_on_route"] == []


def test_i_tratti_saturi_sono_oltre_la_soglia_e_hanno_la_provenienza(analysis: Analysis) -> None:
    data = ask(analysis, "stazione Centrale", "Mergellina", "16:45")
    threshold = EngineConfig.from_yaml().metrics.vc_critical_threshold
    saturated = data["congested_on_route"] + data["congested_nearby"]
    assert saturated, "alle 16:45 il modello ha tratti saturi vicino al percorso"
    for street in saturated:
        assert street["vc"]["value"] > threshold and street["vc"]["kind"] == "simulated"
        assert street["vc"]["unit"] == "rapporto" and street["street_name"]
    names = [s["street_name"] for s in data["congested_on_route"]]
    assert not set(names) & {s["street_name"] for s in data["congested_nearby"]}  # senza doppioni


def test_la_risposta_e_deterministica_e_la_cache_la_rende_rapida(analysis: Analysis) -> None:
    started = time.perf_counter()
    one = ask(analysis, "Molo Beverello", "Fuorigrotta", "13:45")
    cold = time.perf_counter() - started
    started = time.perf_counter()
    two = ask(analysis, "Molo Beverello", "Fuorigrotta", "13:45")
    warm = time.perf_counter() - started
    assert one == two
    assert warm < WARM_SECONDS and cold < COLD_SECONDS


def test_la_rete_condivisa_con_i_motori_non_e_stata_toccata(analysis: Analysis) -> None:
    before = graph_fingerprint(analysis.graph)
    ask(analysis, "piazza Garibaldi", "via Tasso", "13:30")
    ask(analysis, "stazione Centrale", "Mergellina", "16:45")
    ask(analysis, "piazza Plebiscito", "Vomero", "10:00")
    assert graph_fingerprint(analysis.graph) == before


def test_l_analisi_non_e_stata_toccata_dalle_domande(analysis: Analysis) -> None:
    """Sola lettura: nessuna riga in più nelle richieste né nel registro dell'analisi."""
    requests = len(analysis.repo.list_operation_requests(analysis.run.id))
    decisions = len(analysis.repo.list_decisions(analysis.run.id))
    ask(analysis, "stazione Centrale", "Mergellina", "16:45")
    assert len(analysis.repo.list_operation_requests(analysis.run.id)) == requests
    assert len(analysis.repo.list_decisions(analysis.run.id)) == decisions
    assert analysis.repo.get_run(analysis.run.id) == analysis.run


# --- la pagina di verifica ---------------------------------------------------------------------


def test_lo_script_di_verifica_scrive_la_pagina_con_le_domande_vere(
    analysis: Analysis,
) -> None:
    """Lo script legge la rete e l'ultima analisi di una cartella dati: qui, quella del test."""
    for name in ("osm", "gtfs"):
        link = analysis.data_dir / name
        if not link.exists():
            link.symlink_to(default_data_dir() / name)
    assert route_check.main(["--event", EVENT, "--data-dir", str(analysis.data_dir)]) == 0
    report = analysis.data_dir / "report"
    page = (report / route_check.HTML_NAME).read_text(encoding="utf-8")
    assert not any(token in page for token in ("__DATA__", "__MAPLIBRE_JS__", "__MAPLIBRE_CSS__"))
    found = re.search(r'<script id="data" type="application/json">(.*?)</script>', page, re.S)
    assert found is not None
    data = json.loads(found.group(1))
    assert [q["number"] for q in data["questions"]] == ["1", "1 bis", "2", "6", "7"]
    assert all(q["routes"] and q["routes"][0]["steps"] for q in data["questions"])
    for layer in ("closures", "saturated", "places"):
        assert data[layer]["features"], layer
    assert len(data["places"]["features"]) == len(PlacesConfig.from_yaml().places)
    assert (report / route_check.GEOJSON_NAME).is_file()
