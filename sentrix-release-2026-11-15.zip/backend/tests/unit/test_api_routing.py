import datetime as dt
import json
import logging
import re
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any

import networkx as nx
import pytest
from fastapi.testclient import TestClient

from app.api.context import AppContext
from app.api.errors import DATA_UNAVAILABLE_MESSAGE
from app.data import route_service
from app.data.gtfs import load_feed
from app.data.map_data import MapData
from app.data.paths import DataPaths
from app.data.resolvers import edge_key
from app.data.route_service import measures_in_force
from app.db.repository import Repository
from app.engine import STATIC_MODEL_ASSUMPTION
from app.engine.graph import build_road_graph
from app.engine.routing import plan_routes, window_costs
from app.main import create_app
from app.models.config import EngineConfig
from app.models.routing import RoutingConfig
from app.settings import Settings
from tests.conftest import FakeClock, log_in
from tests.orchestrator_support import engines_with
from tests.support import (
    GTFS_FIXTURE,
    HUB,
    build_star_raw_graph,
    ctx_of,
    graph_fingerprint,
    make_event,
    make_request,
    make_run,
)
from tests.unit.test_api_network import mini_config

ENDED = "2026-11-09T10:01:00+01:00"
OLDER = "2026-11-09T09:00:00+01:00"
NEWER = "2026-11-09T10:00:00+01:00"
SOURCE_REF = "Ordinanza di prova n. 1"


@dataclass
class World:
    client: TestClient
    repo: Repository
    road: nx.MultiDiGraph
    config: EngineConfig
    spokes: list[int]  # i nodi della stella, in ordine

    def search(self, text: str) -> list[dict[str, Any]]:
        response = self.client.get("/api/places/search", params={"q": text})
        assert response.status_code == 200, response.text
        return list(response.json())

    def node_of(self, text: str) -> int:
        return int(self.search(text)[0]["node_id"])

    def route(self, start: str | int, end: str | int, at: str, **extra: Any) -> Any:
        a = start if isinstance(start, int) else self.node_of(start)
        b = end if isinstance(end, int) else self.node_of(end)
        body = {"event_id": "gara", "from_node": a, "to_node": b, "time": at, **extra}
        return self.client.post("/api/route", json=body)


def both(a: int, b: int) -> list[str]:
    return [edge_key(a, b, 0), edge_key(b, a, 0)]


def build_world(settings: Settings, clock: FakeClock, **event: Any) -> Iterator[World]:
    config = mini_config()
    raw = build_star_raw_graph(config)
    spokes = sorted(n for n in raw.nodes if n != HUB)
    for a, b, name in (
        (spokes[0], spokes[1], "Via Diretta Uno"),
        (spokes[1], spokes[2], "Via Diretta Due"),
    ):
        for u, v in (
            (a, b),
            (b, a),
        ):  # due raccordi diretti: esistono alternative al passaggio dal centro
            raw.add_edge(u, v, key=0, length_m=400.0, highway="primary", oneway=False, name=name)
    road = build_road_graph(raw, config)
    feed = load_feed(GTFS_FIXTURE)
    map_data = MapData(DataPaths(settings.data_dir), graph=road, feed=feed, config=config)
    app = create_app(settings, clock=clock, engines=engines_with(()), map_data=map_data)
    with TestClient(app) as client:
        log_in(client)
        repo = ctx_of(app).repo
        repo.add_event(make_event(id="gara", name="Gara di prova", **event))
        yield World(client, repo, road, config, spokes)


def done(
    repo: Repository, run_id: str, *, started: str = NEWER, iteration: int = 1, **changes: Any
) -> None:
    run = make_run(
        run_id,
        event_id="gara",
        event_revision=1,
        state="DONE",
        iteration=iteration,
        started_at=started,
        ended_at=ENDED,
        **changes,
    )
    repo.add_run(run)


@pytest.fixture
def world(settings: Settings, clock: FakeClock) -> Iterator[World]:
    yield from build_world(settings, clock)


@pytest.fixture
def closed_world(settings: Settings, clock: FakeClock) -> Iterator[World]:
    """Lo stesso, con il raccordo diretto Uno chiuso dall'Evento."""
    config = mini_config()
    spokes = sorted(n for n in build_star_raw_graph(config).nodes if n != HUB)
    closure = {
        "label": "Via Diretta Uno",
        "edge_keys": both(spokes[0], spokes[1]),
        "source_ref": SOURCE_REF,
    }
    yield from build_world(settings, clock, closures=[closure])


# --- senza sessione e con il servizio spento --------------------


def test_senza_sessione_401(client: TestClient) -> None:
    assert client.get("/api/places/search", params={"q": "x"}).status_code == 401
    body = {"event_id": "gara", "from_node": 1, "to_node": 2, "time": "13:30"}
    assert client.post("/api/route", json=body).status_code == 401


@pytest.mark.parametrize("params", [{}, {"q": ""}, {"q": "x" * 201}])
def test_la_ricerca_vuole_un_testo_da_1_a_200_caratteri(
    world: World, params: dict[str, str]
) -> None:
    response = world.client.get("/api/places/search", params=params)
    assert response.status_code == 400 and response.json()["error"]["code"] == "VALIDATION_ERROR"


@pytest.mark.parametrize(
    "change",
    [
        {"time": "25:00"},
        {"time": "13:30:99"},
        {"time": 1330},
        {"time": None},
        {"from_node": "casa"},
        {"to_node": None},
        {"event_id": "Evento Maiuscolo"},
        {"run_id": "con spazi"},
        {"colore": "rosso"},
    ],
)
def test_una_richiesta_di_percorso_non_valida_e_400(world: World, change: dict[str, Any]) -> None:
    body = {"event_id": "gara", "from_node": 1, "to_node": 2, "time": "13:30", **change}
    response = world.client.post("/api/route", json=body)
    assert response.status_code == 400 and response.json()["error"]["code"] == "VALIDATION_ERROR"


def test_senza_il_file_dei_parametri_il_servizio_risponde_503_e_il_resto_funziona(
    settings: Settings,
    clock: FakeClock,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    def broken(*_: object, **__: object) -> None:
        raise ValueError("file non valido")

    monkeypatch.setattr("app.api.context.RoutingConfig.from_yaml", broken)
    with caplog.at_level(logging.ERROR):
        for world in build_world(settings, clock):
            ctx: AppContext = ctx_of(world.client.app)  # type: ignore[arg-type]
            assert ctx.places is None and ctx.routes is None
            response = world.client.get("/api/places/search", params={"q": "Fuorigrotta"})
            assert (response.status_code, response.json()["error"]["code"]) == (
                503,
                "ROUTING_UNAVAILABLE",
            )
            body = {"event_id": "gara", "from_node": 1, "to_node": 2, "time": "13:30"}
            assert world.client.post("/api/route", json=body).status_code == 503
            assert world.client.get("/api/events").status_code == 200  # il resto non risente
    assert "routing.yaml non letto" in caplog.text


def test_senza_il_file_dei_luoghi_la_ricerca_funziona_con_cio_che_ricava_da_se(
    settings: Settings,
    clock: FakeClock,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    def broken(*_: object, **__: object) -> None:
        raise ValueError("file non valido")

    monkeypatch.setattr("app.api.context.PlacesConfig.from_yaml", broken)
    with caplog.at_level(logging.ERROR):
        for world in build_world(settings, clock):
            found = world.search("Fuorigrotta")  # una zona di engine.yaml: non serve places.yaml
            assert found and found[0]["kind"] == "zone"
    assert "places.yaml non letto" in caplog.text


def test_senza_i_dati_della_mappa_503_senza_percorsi_del_server(
    settings: Settings, clock: FakeClock, caplog: pytest.LogCaptureFixture
) -> None:
    app = create_app(settings, clock=clock, engines=engines_with(()))  # nessun grafo in tmp_path
    with TestClient(app) as client, caplog.at_level(logging.ERROR, logger="app.api.errors"):
        log_in(client)
        repo = ctx_of(app).repo
        repo.add_run(
            make_run("r1", event_id="match_2027", state="DONE", iteration=1, ended_at=ENDED)
        )
        search = client.get("/api/places/search", params={"q": "Tasso"})
        body = {"event_id": "match_2027", "from_node": 1, "to_node": 2, "time": "13:30"}
        route = client.post("/api/route", json=body)
    for response in (search, route):
        assert response.status_code == 503
        assert response.json()["error"]["message"] == DATA_UNAVAILABLE_MESSAGE
        assert str(settings.data_dir) not in response.text


# --- la ricerca --------------------


def test_la_ricerca_da_candidati_con_nodo_e_punteggio(world: World) -> None:
    found = world.search("Fuorigrotta")
    assert found[0]["kind"] == "zone" and found[0]["label"] == "Fuorigrotta"
    assert set(found[0]) == {"id", "label", "kind", "node_id", "lon", "lat", "score", "long_street"}
    assert found[0]["score"] == 1.0 and found[0]["node_id"] in world.road.nodes
    assert len(found) <= 5


def test_la_ricerca_e_di_sola_lettura_e_non_tocca_la_rete(world: World) -> None:
    before = graph_fingerprint(world.road)
    world.search("Fuorigrotta")
    world.search("Via Diretta Uno")
    assert graph_fingerprint(world.road) == before


# --- il percorso: struttura e provenienza --------------------


def test_il_percorso_ha_la_struttura_della_spec_e_ogni_numero_la_sua_provenienza(
    world: World,
) -> None:
    done(world.repo, "run_a")
    response = world.route("Chiaia", "Fuorigrotta", "13:30")
    assert response.status_code == 200, response.text
    data = response.json()
    assert set(data) == {
        "routes",
        "avoided_closures",
        "congested_on_route",
        "congested_nearby",
        "context",
    }
    assert data["context"] == {
        "event": "Gara di prova",
        "date": "2026-09-26",
        "time": "13:30:00",
        "window": "arrival",
        "peak": "13:30:00",
        "iteration": 1,
        "run_id": "run_a",
    }
    main = data["routes"][0]
    assert set(main) == {"steps", "duration", "length", "geometry"}
    assert main["steps"] and all(set(s) == {"street_name", "length_m"} for s in main["steps"])
    assert main["geometry"]["type"] == "LineString" and len(main["geometry"]["coordinates"]) >= 2
    for measured in (main["duration"], main["length"]):
        assert measured["kind"] == "simulated" and measured["source"] == "engine.routing v1"
        assert STATIC_MODEL_ASSUMPTION in measured["assumptions"]
        assert measured["method"] and measured["inputs"]
        assert dt.datetime.fromisoformat(measured["as_of"]) == dt.datetime.fromisoformat(ENDED)
        assert re.fullmatch(r"m(\.[A-Za-z0-9_-]+)+", measured["id"])
    assert (main["duration"]["unit"], main["length"]["unit"]) == ("min", "km")
    assert any("run_a" in i for i in main["duration"]["inputs"])
    assert main["duration"]["id"] != main["length"]["id"]


def test_tempo_e_lunghezza_sono_quelli_del_motore(world: World) -> None:
    """L'API non calcola nulla di suo: stesso risultato di `window_costs` + `plan_routes`."""
    done(world.repo, "run_a")
    a, b = world.node_of("Chiaia"), world.node_of("Fuorigrotta")
    event = world.repo.get_event("gara")
    assert event is not None
    costs = window_costs(world.road, event, "mid", "arrival", [], world.config)
    routing = RoutingConfig.from_yaml().route
    expected = plan_routes(
        costs.graph, costs.loads, a, b, penalty=routing.alternative_penalty,
        max_longer_pct=routing.alternative_max_longer_pct,
        max_overlap_pct=routing.alternative_max_overlap_pct,
    )  # fmt: skip
    data = world.route(a, b, "13:30").json()
    assert data["routes"][0]["duration"]["value"] == round(expected[0].time_min, 1)
    assert data["routes"][0]["length"]["value"] == round(expected[0].length_m / 1000, 2)
    assert len(data["routes"]) == len(expected)


def test_i_passi_sono_quelli_degli_archi_e_si_uniscono_per_nome(world: World) -> None:
    done(world.repo, "run_a")
    data = world.route(world.spokes[0], world.spokes[1], "13:30").json()
    steps = data["routes"][0]["steps"]
    assert [s["street_name"] for s in steps] == ["Via Diretta Uno"]  # il raccordo diretto, 400 m
    assert steps[0]["length_m"] == 400.0
    assert data["routes"][0]["length"]["value"] == 0.4


def test_la_risposta_e_deterministica(world: World) -> None:
    done(world.repo, "run_a")
    one = world.route("Chiaia", "Fuorigrotta", "13:30").text
    two = world.route("Chiaia", "Fuorigrotta", "13:30").text
    assert one == two


def test_il_percorso_non_modifica_la_rete(world: World) -> None:
    done(world.repo, "run_a")
    before = graph_fingerprint(world.road)
    for at in ("13:30", "17:00", "10:00"):
        assert world.route("Chiaia", "Fuorigrotta", at).status_code == 200
    assert graph_fingerprint(world.road) == before


# --- la fascia dell'ora --------------------


@pytest.mark.parametrize(
    ("at", "window", "peak", "kind"),
    [
        ("12:00", "arrival", "13:30:00", "simulated"),
        ("13:45", "arrival", "13:30:00", "simulated"),
        ("14:59", "arrival", "13:30:00", "simulated"),
        ("15:00", "none", None, "estimate"),
        ("10:00", "none", None, "estimate"),
        ("18:00", "departure", "18:30:00", "simulated"),
        ("20:59", "departure", "18:30:00", "simulated"),
        ("21:00", "none", None, "estimate"),
        ("00:00", "none", None, "estimate"),
    ],
)
def test_la_fascia_viene_dall_ora_e_dall_evento(
    world: World, at: str, window: str, peak: str | None, kind: str
) -> None:
    done(world.repo, "run_a")
    data = world.route("Chiaia", "Fuorigrotta", at).json()
    assert (data["context"]["window"], data["context"]["peak"]) == (window, peak)
    assert data["routes"][0]["duration"]["kind"] == kind


def test_fuori_fascia_niente_traffico_ma_si_dice_e_ci_sono_le_chiusure(closed_world: World) -> None:
    done(closed_world.repo, "run_a")
    data = closed_world.route(closed_world.spokes[0], closed_world.spokes[1], "10:00").json()
    assert data["congested_on_route"] == [] and data["congested_nearby"] == []
    duration = data["routes"][0]["duration"]
    assert any("strada libera" in a for a in duration["assumptions"])  # lo dice
    assert [c["label"] for c in data["avoided_closures"]] == [
        "Via Diretta Uno"
    ]  # ma le chiusure valgono
    assert "Via Diretta Uno" not in [s["street_name"] for s in data["routes"][0]["steps"]]


def test_fuori_fascia_il_tempo_e_a_strada_libera_in_fascia_con_il_traffico_e_piu_lungo(
    world: World,
) -> None:
    done(world.repo, "run_a")
    free = world.route("Chiaia", "Fuorigrotta", "10:00").json()["routes"][0]["duration"]["value"]
    busy = world.route("Chiaia", "Fuorigrotta", "13:30").json()["routes"][0]["duration"]["value"]
    assert busy >= free


# --- chiusure e misure --------------------


def test_una_chiusura_dell_evento_si_aggira_e_si_dice_quale(closed_world: World) -> None:
    done(closed_world.repo, "run_a")
    a, b = closed_world.spokes[0], closed_world.spokes[1]
    data = closed_world.route(a, b, "13:30").json()
    assert data["avoided_closures"] == [{"label": "Via Diretta Uno", "source_ref": SOURCE_REF}]
    steps = [s["street_name"] for s in data["routes"][0]["steps"]]
    assert "Via Diretta Uno" not in steps  # passa dal centro
    assert data["routes"][0]["length"]["value"] > 0.4


def test_senza_chiusure_si_usa_il_raccordo_e_non_c_e_nulla_da_evitare(world: World) -> None:
    done(world.repo, "run_a")
    data = world.route(world.spokes[0], world.spokes[1], "13:30").json()
    assert data["avoided_closures"] == []
    assert [s["street_name"] for s in data["routes"][0]["steps"]] == ["Via Diretta Uno"]


def close_request(spokes: list[int], window: str, **changes: Any) -> Any:
    fields: dict[str, Any] = {"state": "ACCEPTED", **changes}
    return make_request(
        "act_close",
        run_id="run_a",
        department="traffic_control",
        type="close_road",
        target=",".join(both(spokes[0], spokes[1])),
        target_label="Raccordo chiuso dalla polizia",
        window=window,
        iteration=1,
        **fields,
    )


def test_una_close_road_accettata_vale_nella_sua_finestra_e_non_nell_altra(world: World) -> None:
    done(world.repo, "run_a")
    world.repo.add_operation_request(close_request(world.spokes, "arrival"))
    arrival = world.route(world.spokes[0], world.spokes[1], "13:30").json()
    assert arrival["avoided_closures"] == [
        {"label": "Raccordo chiuso dalla polizia", "source_ref": "misura act_close"}
    ]
    assert "Via Diretta Uno" not in [s["street_name"] for s in arrival["routes"][0]["steps"]]
    for at in ("17:00", "10:00"):  # un'altra finestra e fuori fascia: la misura non vale
        other = world.route(
            world.spokes[0], world.spokes[1], "18:30" if at == "17:00" else at
        ).json()
        assert other["avoided_closures"] == []
        assert [s["street_name"] for s in other["routes"][0]["steps"]] == ["Via Diretta Uno"]


def test_una_misura_non_accettata_e_l_avviso_ai_cittadini_non_contano(world: World) -> None:
    done(world.repo, "run_a")
    world.repo.add_operation_request(
        close_request(
            world.spokes, "arrival", reject_code="X", reject_reason="no", state="REJECTED"
        )
    )
    notice = make_request(
        "act_notice", run_id="run_a", department="public_comms", type="citizen_notice",
        target="all", target_label="Cittadini", window="arrival", iteration=1, state="ACCEPTED",
    )  # fmt: skip
    world.repo.add_operation_request(notice)
    data = world.route(world.spokes[0], world.spokes[1], "13:30").json()
    assert data["avoided_closures"] == []
    assert [s["street_name"] for s in data["routes"][0]["steps"]] == ["Via Diretta Uno"]


def test_le_misure_in_vigore_sono_accettate_in_corso_o_completate_senza_l_avviso() -> None:
    states = ("CREATED", "SENT", "RECEIVED", "ACCEPTED", "REJECTED", "IN_PROGRESS", "COMPLETED")
    requests = [
        make_request(
            f"a{n}",
            state=state,
            **({"reject_code": "X", "reject_reason": "no"} if state == "REJECTED" else {}),
        )  # fmt: skip
        for n, state in enumerate(states)
    ] + [make_request("notice", type="citizen_notice", state="ACCEPTED")]
    assert [r.state for r in measures_in_force(requests)] == [
        "ACCEPTED",
        "IN_PROGRESS",
        "COMPLETED",
    ]


def test_senza_percorso_dopo_le_chiusure_404(settings: Settings, clock: FakeClock) -> None:
    config = mini_config()
    spokes = sorted(n for n in build_star_raw_graph(config).nodes if n != HUB)
    cut = [edge_key(HUB, spokes[5], 0), edge_key(spokes[5], HUB, 0)]  # il nodo resta isolato
    closure = {"label": "Raggio chiuso", "edge_keys": cut}
    for world in build_world(settings, clock, closures=[closure]):
        done(world.repo, "run_a")
        response = world.route(spokes[3], spokes[5], "13:30")
        assert response.status_code == 404
        assert response.json()["error"]["code"] == "NO_ROUTE"


# --- l'analisi da usare --------------------


def test_si_usa_l_ultima_analisi_completata_e_si_ignorano_le_altre(world: World) -> None:
    done(world.repo, "run_old", started=OLDER)
    done(world.repo, "run_new", started=NEWER)
    world.repo.add_run(
        make_run("run_busy", event_id="gara", started_at="2026-11-09T11:00:00+01:00")
    )
    world.repo.add_run(
        make_run(
            "run_failed",
            event_id="gara",
            state="ERROR",
            error="x",
            ended_at="2026-11-09T12:05:00+01:00",
            started_at="2026-11-09T12:00:00+01:00",
        )  # fmt: skip
    )
    assert world.route("Chiaia", "Fuorigrotta", "13:30").json()["context"]["run_id"] == "run_new"
    explicit = world.route("Chiaia", "Fuorigrotta", "13:30", run_id="run_old")
    assert explicit.json()["context"]["run_id"] == "run_old"


def test_si_usa_l_ultima_iterazione_dell_analisi(world: World) -> None:
    done(world.repo, "run_a", iteration=2)
    assert world.route("Chiaia", "Fuorigrotta", "13:30").json()["context"]["iteration"] == 2


def test_i_dati_dell_evento_sono_quelli_della_revisione_dell_analisi(world: World) -> None:
    done(world.repo, "run_a")
    current = world.repo.get_event("gara")
    assert current is not None
    world.repo.update_event(current.model_copy(update={"name": "Nome cambiato dopo"}))
    assert (
        world.route("Chiaia", "Fuorigrotta", "13:30").json()["context"]["event"] == "Gara di prova"
    )


@pytest.mark.parametrize(
    ("setup", "extra", "status", "code"),
    [
        ("none", {}, 404, "NO_COMPLETED_RUN"),  # l'evento non ha analisi completate
        ("busy", {}, 404, "NO_COMPLETED_RUN"),  # solo una in corso
        ("done", {"run_id": "run_x"}, 404, "NOT_FOUND"),  # l'analisi non c'è
        ("done", {"run_id": "run_busy"}, 409, "RUN_NOT_COMPLETED"),
        ("done", {"run_id": "run_other"}, 400, "VALIDATION_ERROR"),  # è di un altro evento
        ("done", {"event_id": "fantasma"}, 404, "NOT_FOUND"),
    ],
)
def test_errori_dell_analisi(
    world: World, setup: str, extra: dict[str, Any], status: int, code: str
) -> None:
    if setup == "done":
        done(world.repo, "run_a")
    world.repo.add_run(make_run("run_busy", event_id="gara"))
    world.repo.add_run(make_run("run_other", event_id="match_2027"))
    response = world.route("Chiaia", "Fuorigrotta", "13:30", **extra)
    assert (response.status_code, response.json()["error"]["code"]) == (status, code)


def test_nodo_inesistente_e_stesso_posto(world: World) -> None:
    done(world.repo, "run_a")
    known = world.node_of("Chiaia")
    missing = 999_999_999
    for field, body in (
        ("from_node", {"from_node": missing, "to_node": known}),
        ("to_node", {"from_node": known, "to_node": missing}),
    ):
        response = world.client.post(
            "/api/route", json={"event_id": "gara", "time": "13:30", **body}
        )
        error = response.json()["error"]
        assert response.status_code == 400 and error["details"]["fields"][0]["path"] == field
    same = world.route(known, known, "13:30")
    assert (same.status_code, same.json()["error"]["code"]) == (400, "SAME_PLACE")


# --- cache dei costi --------------------


class Counter:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def wrap(self, name: str, function: Any) -> Any:
        def counted(*args: Any, **kwargs: Any) -> Any:
            self.calls.append(name)
            return function(*args, **kwargs)

        return counted


def test_i_costi_di_una_fascia_si_calcolano_una_volta_sola(
    world: World, monkeypatch: pytest.MonkeyPatch
) -> None:
    counter = Counter()
    monkeypatch.setattr(
        route_service, "window_costs", counter.wrap("window", route_service.window_costs)
    )
    monkeypatch.setattr(
        route_service, "free_flow_costs", counter.wrap("free", route_service.free_flow_costs)
    )
    done(world.repo, "run_a")
    for _ in range(3):
        world.route("Chiaia", "Fuorigrotta", "13:30")  # arrivi
    assert counter.calls == ["window"]
    world.route("Chiaia", "Fuorigrotta", "13:45")  # ancora arrivi: dalla cache
    assert counter.calls == ["window"]
    world.route("Chiaia", "Fuorigrotta", "18:30")  # deflusso
    world.route("Chiaia", "Fuorigrotta", "10:00")  # fuori fascia
    world.route("Chiaia", "Fuorigrotta", "11:00")
    assert counter.calls == ["window", "window", "free"]


def test_un_altra_analisi_ricalcola_e_la_cache_ha_un_limite(
    world: World, monkeypatch: pytest.MonkeyPatch
) -> None:
    counter = Counter()
    monkeypatch.setattr(
        route_service, "window_costs", counter.wrap("window", route_service.window_costs)
    )
    done(world.repo, "run_a", started=OLDER)
    done(world.repo, "run_b", started=NEWER)
    world.route("Chiaia", "Fuorigrotta", "13:30", run_id="run_a")
    world.route("Chiaia", "Fuorigrotta", "13:30", run_id="run_b")
    assert counter.calls == ["window", "window"]  # un'altra analisi, un altro calcolo
    monkeypatch.setattr(route_service, "CACHE_SIZE", 1)
    world.route("Chiaia", "Fuorigrotta", "18:30", run_id="run_b")  # fa uscire la voce più vecchia
    world.route("Chiaia", "Fuorigrotta", "13:30", run_id="run_b")
    assert counter.calls == ["window"] * 4  # la voce degli arrivi era uscita: si rifà


def test_il_risultato_non_dipende_dalla_cache(
    world: World, monkeypatch: pytest.MonkeyPatch
) -> None:
    done(world.repo, "run_a")
    warm = world.route("Chiaia", "Fuorigrotta", "13:30").text
    monkeypatch.setattr(route_service, "CACHE_SIZE", 0)
    cold = world.route("Chiaia", "Fuorigrotta", "13:30").text
    assert warm == cold
    assert json.loads(warm)["routes"]  # e non è vuoto
