import datetime as dt
import json
import re

from scripts import route_check
from scripts.resolve_seeds import MAPLIBRE_CSS_SRI, MAPLIBRE_JS_SRI

PLACEHOLDERS = (
    "__MAPLIBRE_CSS__",
    "__MAPLIBRE_CSS_SRI__",
    "__MAPLIBRE_JS__",
    "__MAPLIBRE_JS_SRI__",
    "__DATA__",
)


def test_la_pagina_ha_ogni_segnaposto_una_volta_sola() -> None:
    for name in PLACEHOLDERS:
        assert route_check.PAGE.count(name) == 1, name


def test_le_domande_hanno_numero_unico_e_un_orario_valido() -> None:
    numbers = [q.number for q in route_check.QUESTIONS]
    assert len(numbers) == len(set(numbers))
    assert {"1", "2", "6", "7"} <= set(numbers)  # quelle del cancello A1 (10 §8)
    for question in route_check.QUESTIONS:
        dt.time.fromisoformat(question.time)
        assert question.start and question.end and question.text


def test_la_pagina_non_scrive_i_dati_come_html_eseguibile() -> None:
    """I dati stanno in un tag <script>: un «</script>» nel testo non deve poterlo chiudere."""
    from scripts.resolve_seeds import script_safe_json

    text = script_safe_json({"label": "</script><script>alert(1)</script>"})
    assert "</script>" not in text and json.loads(text)["label"].startswith("</script>")


def test_le_costanti_della_mappa_sono_quelle_di_resolve_seeds() -> None:
    assert re.fullmatch(r"sha384-[A-Za-z0-9+/=]+", MAPLIBRE_JS_SRI)
    assert re.fullmatch(r"sha384-[A-Za-z0-9+/=]+", MAPLIBRE_CSS_SRI)
    assert route_check.MAPLIBRE_BASE.endswith("/maplibre-gl/4.7.1")
