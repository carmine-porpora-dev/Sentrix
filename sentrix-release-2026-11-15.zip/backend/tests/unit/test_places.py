import logging
from pathlib import Path
from typing import Any

import networkx as nx
import pandas as pd
import pytest
from pydantic import ValidationError

from app.data.gtfs import GtfsFeed, RouteClasses
from app.data.map_data import MapData
from app.data.paths import DataPaths
from app.data.places import (
    EXACT,
    PlaceDirectory,
    PlaceIndex,
    Station,
    build_entries,
    rail_stations,
)
from app.models.config import EngineConfig
from app.models.places import KnownPlace, PlacesConfig
from app.models.routing import RoutingConfig, SearchConfig
from tests.support import HUB, build_star_raw_graph

LABELS = {
    "metro_line_1": "Linea 1",
    "metro_line_6": "Linea 6",
    "funicular": "Funicolari",
}


@pytest.fixture(scope="module")
def config() -> EngineConfig:
    return EngineConfig.from_yaml()


@pytest.fixture(scope="module")
def search() -> SearchConfig:
    return RoutingConfig.from_yaml().search


def town(config: EngineConfig) -> nx.MultiDiGraph:
    """La stella dei test (un nodo per ogni punto di `engine.yaml`) con qualche strada a Napoli."""
    graph = build_star_raw_graph(config)
    counter = iter(range(1000, 2000))

    def node(lat: float, lon: float) -> int:
        number = next(counter)
        graph.add_node(number, x=lon, y=lat)
        return number

    def both(u: int, v: int, name: str | None) -> None:
        for a, b in ((u, v), (v, u)):
            graph.add_edge(a, b, key=0, length_m=100.0, highway="residential", name=name)

    def chain(name: str, points: list[tuple[float, float]], link: bool = True) -> list[int]:
        nodes = [node(lat, lon) for lat, lon in points]
        for a, b in zip(nodes, nodes[1:], strict=False):
            both(a, b, name)
        if link:
            both(HUB, nodes[0], None)  # un raccordo senza nome: la strada è nella rete principale
        return nodes

    chain("Via Torquato Tasso", [(40.8330, 14.2360 + 0.0045 * i) for i in range(5)])  # ~1,5 km
    # Falcone passa a ~14 m da Tasso senza condividerne un nodo; più in là un altro pezzo, con una
    # strada che lo incrocia
    chain("Via Aniello Falcone", [(40.8345, 14.24055), (40.83312, 14.24055), (40.8315, 14.24055)])
    far = chain("Via Aniello Falcone", [(40.8780, 14.2400), (40.8800, 14.2400), (40.8820, 14.2400)])
    both(far[1], node(40.8800, 14.2430), "Via Lontana")
    # due pezzi della stessa piazza, a ~50 m: sono un luogo solo
    chain("Piazza del Plebiscito", [(40.8290, 14.2280), (40.8290, 14.2290)])
    chain("Piazza del Plebiscito", [(40.8290, 14.2296), (40.8290, 14.2306)])
    # la stessa strada in due posti lontani
    chain("Via Francesco Caracciolo", [(40.8300, 14.2300), (40.8300, 14.2340)])
    chain("Via Francesco Caracciolo", [(40.8500, 14.2600), (40.8500, 14.2640)])
    chain("Via Nardone; Gradoni di Chiaia", [(40.8350, 14.2200), (40.8350, 14.2210)])
    chain("Via Isolata", [(40.8400, 14.2100), (40.8400, 14.2110)], link=False)  # fuori dalla rete
    chain("Fuorigrotta", [(40.8420, 14.2200), (40.8420, 14.2210)])  # come una zona di engine.yaml
    return graph


def known(text: str = "places: []") -> PlacesConfig:
    return PlacesConfig.from_yaml_text(text)


def index(
    config: EngineConfig,
    search: SearchConfig,
    stations: list[Station] | None = None,
    places: PlacesConfig | None = None,
    graph: nx.MultiDiGraph | None = None,
) -> PlaceIndex:
    graph = graph or town(config)
    entries = build_entries(graph, config, places or known(), stations or [], LABELS, search)
    return PlaceIndex(entries, search, graph)


@pytest.fixture(scope="module")
def city(config: EngineConfig, search: SearchConfig) -> PlaceIndex:
    return index(config, search)


def labels(found: list[Any]) -> list[str]:
    return [c.label for c in found]


# --- per nome, per parole, per somiglianza --------------------


def test_il_nome_intero_vale_uno_e_vince_sulle_parole(city: PlaceIndex) -> None:
    found = city.search("Via Torquato Tasso")
    assert (found[0].label, found[0].score, found[0].kind) == (
        "Via Torquato Tasso",
        EXACT,
        "street",
    )


def test_per_parole_il_punteggio_cresce_con_le_parole_trovate(city: PlaceIndex) -> None:
    assert city.search("via Tasso")[0].score == 0.8  # 2 parole su 3
    assert city.search("Tasso")[0].score == 0.65  # 1 su 3


def test_maiuscole_accenti_e_punteggiatura_non_contano(city: PlaceIndex) -> None:
    for text in ("VIA  torquato-tasso!", "  via TORQUATO tasso ", "via Torquato Tasso."):
        assert city.search(text)[0].score == EXACT, text


def test_le_abbreviazioni_si_espandono(city: PlaceIndex) -> None:
    assert city.search("v. Tasso")[0].label == "Via Torquato Tasso"
    assert city.search("p.zza del Plebiscito")[0].score == EXACT


def test_un_errore_di_battitura_si_trova_per_somiglianza_con_un_punteggio_basso(
    city: PlaceIndex,
) -> None:
    found = city.search("plebicito")
    assert found and found[0].label == "Piazza del Plebiscito"
    assert 0 < found[0].score <= 0.45


def test_la_somiglianza_si_usa_solo_se_non_c_e_altro(city: PlaceIndex) -> None:
    """Con una corrispondenza per parole non si cerca per somiglianza (10 §4.1: prima la
    corrispondenza esatta, poi per parole, poi approssimata): niente punteggi da 0,45 in giù."""
    assert all(c.score >= 0.5 for c in city.search("Tasso"))
    assert all(
        c.score <= 0.45 for c in city.search("Torquato Tassso")
    )  # il refuso, solo approssimato


def test_una_ricerca_con_troppe_parole_non_trova_nulla_e_non_costa(
    city: PlaceIndex, search: SearchConfig
) -> None:
    """Difesa dagli abusi: nessun nome ha più di `max_query_words` parole, e un testo di 200
    caratteri non deve occupare il server per un secondo."""
    many = " ".join(f"parola{n}" for n in range(search.max_query_words + 1))
    assert city.search(many) == []
    assert city.search("a" * 200) == []
    assert city.search(f"via {many} angolo via {many}") == []  # nemmeno come incrocio
    assert city.search(" ".join(["via"] * 50))  # la stessa parola ripetuta è una parola sola


def test_un_testo_sotto_il_tetto_si_cerca_ancora(city: PlaceIndex) -> None:
    assert city.search("plebicito")  # il refuso breve continua a trovarsi


def test_senza_corrispondenze_non_c_e_nulla(city: PlaceIndex) -> None:
    for text in ("xyzzy", "", "   ", "...", "!!!"):
        assert city.search(text) == [], repr(text)


def test_una_strada_fuori_dalla_rete_principale_non_si_propone(city: PlaceIndex) -> None:
    assert city.search("Via Isolata") == []


def test_l_etichetta_di_una_zona_con_la_barra_non_e_un_incrocio(city: PlaceIndex) -> None:
    """«Stazione Centrale / Garibaldi» contiene «/», come un incrocio: si trova lo stesso."""
    found = city.search("Stazione Centrale / Garibaldi")
    assert found[0].label == "Stazione Centrale / Garibaldi" and found[0].score == EXACT
    assert found[0].kind == "zone"


def test_i_nomi_fusi_da_osm_si_cercano_per_ognuna_delle_parti(city: PlaceIndex) -> None:
    assert city.search("Gradoni di Chiaia")[0].label == "Gradoni di Chiaia"
    assert city.search("Via Nardone")[0].label == "Via Nardone"


def test_la_ricerca_e_deterministica(config: EngineConfig, search: SearchConfig) -> None:
    one, two = index(config, search), index(config, search)
    for text in ("Tasso", "Caracciolo", "Garibaldi", "chiaia"):
        assert one.search(text) == two.search(text) == one.search(text)


# --- strade con più pezzi --------------------


def test_i_pezzi_vicini_di_una_strada_sono_un_luogo_solo(city: PlaceIndex) -> None:
    found = city.search("Piazza del Plebiscito")
    assert [c.label for c in found if c.kind == "street"] == ["Piazza del Plebiscito"]


def test_la_stessa_strada_in_due_posti_lontani_da_due_candidati_che_dicono_dove(
    city: PlaceIndex,
) -> None:
    found = [c for c in city.search("Via Francesco Caracciolo") if c.kind == "street"]
    assert len(found) == 2 and found[0].node_id != found[1].node_id
    assert all(c.label.startswith("Via Francesco Caracciolo (") for c in found)
    assert len({c.label for c in found}) == 2  # distinguibili


def test_il_pezzo_di_un_nome_con_un_incrocio_dice_presso_quale(city: PlaceIndex) -> None:
    far = [c for c in city.search("Via Aniello Falcone") if c.kind == "street"]
    assert "Via Aniello Falcone (presso Via Lontana)" in labels(far)


def test_una_strada_estesa_oltre_la_soglia_e_lunga(city: PlaceIndex) -> None:
    assert city.search("Via Torquato Tasso")[0].long_street is True  # ~1,5 km
    assert city.search("Piazza del Plebiscito")[0].long_street is False
    assert city.search("Via Nardone")[0].long_street is False


def test_il_nodo_di_una_strada_e_il_suo_nodo_piu_centrale(city: PlaceIndex) -> None:
    found = city.search("Via Torquato Tasso")[0]
    assert (found.lat, found.lon) == pytest.approx((40.8330, 14.2450))  # il terzo dei cinque


# --- incroci --------------------


def test_un_incrocio_si_trova_anche_se_osm_non_ha_un_nodo_comune(city: PlaceIndex) -> None:
    """Tasso e Falcone distano 14 m e non condividono nodi: entro `crossing_m` è l'incrocio."""
    found = city.search("via Tasso angolo via Aniello Falcone")
    assert [c.label for c in found] == ["Via Torquato Tasso / Via Aniello Falcone"]
    assert (found[0].lat, found[0].lon) == (40.8330, 14.2405)  # il nodo di Tasso, a 14 m
    assert found[0].long_street is False and found[0].kind == "street"


@pytest.mark.parametrize(
    "text",
    [
        "via Tasso incrocio via Aniello Falcone",
        "via Tasso / via Aniello Falcone",
        "VIA TASSO  Angolo  VIA ANIELLO FALCONE",
        "Via Aniello Falcone angolo via Tasso",
    ],
)
def test_le_parole_dell_incrocio_e_l_ordine_non_contano(city: PlaceIndex, text: str) -> None:
    found = city.search(text)
    assert len(found) == 1 and "Tasso" in found[0].label and "Falcone" in found[0].label


def test_due_strade_che_non_si_incontrano_non_hanno_incrocio(city: PlaceIndex) -> None:
    assert city.search("via Tasso angolo via Lontana") == []
    assert city.search("via Tasso angolo via Tasso") == []  # la stessa strada, due volte


def test_la_tolleranza_dell_incrocio_e_un_parametro(
    config: EngineConfig, search: SearchConfig
) -> None:
    strict = index(config, search.model_copy(update={"crossing_m": 5.0}))
    assert strict.search("via Tasso angolo via Aniello Falcone") == []


# --- zone, punti, luoghi noti --------------------


def test_le_zone_e_i_punti_di_engine_yaml_si_cercano_per_nome_e_per_parti(city: PlaceIndex) -> None:
    assert city.search("Fuorigrotta")[0].kind == "zone"
    assert city.search("stazione centrale")[0].label == "Stazione Centrale / Garibaldi"
    assert city.search("Molo Beverello")[0].label == "Porto / Molo Beverello"
    assert city.search("piazza Garibaldi")[0].kind == "place"  # un punto O/D con etichetta


def test_un_luogo_noto_su_una_zona_aggiunge_nomi_alla_zona(
    config: EngineConfig, search: SearchConfig
) -> None:
    places = known(
        "places:\n  - {id: napoli_centrale, zone: central_station, aliases: [napoli centrale]}"
    )
    found = index(config, search, places=places).search("Napoli Centrale")
    assert found[0].label == "Stazione Centrale / Garibaldi" and found[0].score == EXACT
    assert found[0].kind == "place"


def test_un_luogo_noto_con_un_punto_si_aggancia_al_nodo_piu_vicino(
    config: EngineConfig, search: SearchConfig
) -> None:
    places = known(
        "places:\n  - {id: maradona, label: Stadio Maradona, lat: 40.8331, lon: 14.2451,"
        " aliases: [maradona, stadio san paolo]}"
    )
    found = index(config, search, places=places).search("stadio san paolo")
    assert found[0].label == "Stadio Maradona" and found[0].score == EXACT
    assert (found[0].lat, found[0].lon) == pytest.approx((40.8330, 14.2450))  # nodo di Tasso


def test_un_luogo_che_non_si_aggancia_alla_rete_si_salta_e_si_dice(
    config: EngineConfig, search: SearchConfig, caplog: pytest.LogCaptureFixture
) -> None:
    places = known("places:\n  - {id: mare, label: Mare aperto, lat: 40.70, lon: 14.00}")
    with caplog.at_level(logging.WARNING):
        found = index(config, search, places=places).search("Mare aperto")
    assert found == [] and "Mare aperto" in caplog.text and "saltato" in caplog.text


def test_una_zona_che_non_esiste_si_segnala(
    config: EngineConfig, search: SearchConfig, caplog: pytest.LogCaptureFixture
) -> None:
    places = known("places:\n  - {id: x, zone: non_esiste, aliases: [qualcosa]}")
    with caplog.at_level(logging.WARNING):
        assert index(config, search, places=places).search("qualcosa") == []
    assert "non_esiste" in caplog.text


# --- stazioni --------------------


def stations() -> list[Station]:
    return [
        Station("DANTE", "metro_line_1", 40.8330, 14.2450),
        Station("MERGELLINA", "metro_line_6", 40.8333, 14.2495),
        Station("MERGELLINA", "funicular", 40.8290, 14.2285),  # 490 m più in là, nel caso vero
    ]


def test_le_stazioni_hanno_la_linea_nell_etichetta(
    config: EngineConfig, search: SearchConfig
) -> None:
    found = index(config, search, stations=stations()).search("Dante")
    assert found[0].kind == "station" and found[0].label == "Dante (Linea 1)"


def test_le_stazioni_omonime_di_linee_diverse_sono_un_candidato_solo_con_la_metro_prima(
    config: EngineConfig, search: SearchConfig
) -> None:
    found = [
        c
        for c in index(config, search, stations=stations()).search("Mergellina")
        if c.kind == "station"
    ]
    assert [c.label for c in found] == ["Mergellina (Linea 6)"]


def test_un_luogo_noto_vince_sulla_stazione_a_pari_punteggio(
    config: EngineConfig, search: SearchConfig
) -> None:
    places = known("places:\n  - {id: p, label: Dante, lat: 40.8331, lon: 14.2451, aliases: []}")
    assert (
        index(config, search, stations=stations(), places=places).search("Dante")[0].kind == "place"
    )


# --- ordine, limiti, doppioni --------------------


def test_a_parita_di_punteggio_vince_luogo_noto_stazione_zona_strada(
    config: EngineConfig, search: SearchConfig
) -> None:
    places = known("places:\n  - {id: fg, label: Fuorigrotta, lat: 40.8330, lon: 14.2495}")
    around = [Station("FUORIGROTTA", "metro_line_1", 40.8290, 14.2306)]
    found = index(config, search, stations=around, places=places).search("Fuorigrotta")
    exact = [c for c in found if c.score == EXACT]
    assert [c.kind for c in exact] == ["place", "station", "zone", "street"]  # decide il tipo
    assert all(c.score < EXACT for c in found if c not in exact)  # gli altri sono solo parziali


def test_i_candidati_non_superano_il_massimo(config: EngineConfig, search: SearchConfig) -> None:
    few = index(config, search.model_copy(update={"max_candidates": 2}))
    assert len(few.search("via")) <= 2


def test_candidati_vicini_sono_lo_stesso_posto_e_resta_il_migliore(city: PlaceIndex) -> None:
    """«Vomero» è una zona e un punto O/D nello stesso posto: un candidato solo, quello noto."""
    found = city.search("Vomero")
    assert found[0].score == EXACT
    assert len({c.node_id for c in found}) == len(found)


def test_il_candidato_ha_le_coordinate_del_suo_nodo(city: PlaceIndex, config: EngineConfig) -> None:
    graph = town(config)
    for candidate in city.search("Tasso") + city.search("Fuorigrotta"):
        assert (candidate.lat, candidate.lon) == (
            graph.nodes[candidate.node_id]["y"],
            graph.nodes[candidate.node_id]["x"],
        )
        assert 0 <= candidate.score <= 1


# --- il feed GTFS --------------------


def feed() -> tuple[GtfsFeed, RouteClasses]:
    stops = pd.DataFrame(
        {
            "stop_id": ["1", "2", "3", "4", "5"],
            "stop_name": ["DANTE", "DANTE ", "MERGELLINA", "MERGELLINA", "FERMATA BUS"],
            "stop_lat": [40.8330, 40.8332, 40.8333, 40.8290, 40.9],
            "stop_lon": [14.2450, 14.2452, 14.2495, 14.2285, 14.3],
        }
    )
    trips = pd.DataFrame(
        {
            "trip_id": ["T1", "T2", "T3", "T4", "T5"],
            "route_id": ["R1", "R1", "R6", "RF", "RB"],
            "service_id": "s",
        }
    )
    stop_times = pd.DataFrame(
        {
            "trip_id": ["T1", "T2", "T3", "T4", "T5"],
            "stop_id": ["1", "2", "3", "4", "5"],
        }
    )
    routes = pd.DataFrame({"route_id": ["R1", "R6", "RF", "RB"]})
    classes = RouteClasses(
        {
            "bus": frozenset({"RB"}),
            "metro_line_1": frozenset({"R1"}),
            "metro_line_6": frozenset({"R6"}),
            "funicular": frozenset({"RF"}),
        }
    )
    return GtfsFeed(Path("."), stops, routes, trips, stop_times, {}), classes


def test_le_stazioni_sono_le_fermate_delle_corse_di_metro_e_funicolari() -> None:
    found = rail_stations(*feed())
    assert sorted((s.name, s.rail_class) for s in found) == [
        ("DANTE", "metro_line_1"),
        ("MERGELLINA", "funicular"),
        ("MERGELLINA", "metro_line_6"),
    ]  # la fermata 5, servita solo da un autobus, non è una stazione


def test_le_banchine_con_lo_stesso_nome_sono_una_stazione_nel_punto_medio() -> None:
    dante = next(s for s in rail_stations(*feed()) if s.name == "DANTE")
    assert dante.lat == pytest.approx(40.8331) and dante.lon == pytest.approx(14.2451)


# --- il dizionario costruito al primo uso --------------------


def directory(config: EngineConfig, search: SearchConfig, tmp_path: Path) -> PlaceDirectory:
    map_data = MapData(DataPaths(tmp_path), graph=town(config), config=config)
    return PlaceDirectory(map_data, known(), search, LABELS)


def test_il_dizionario_si_costruisce_una_volta_sola(
    config: EngineConfig, search: SearchConfig, tmp_path: Path
) -> None:
    unique = directory(config, search, tmp_path)
    assert unique.index() is unique.index()
    assert unique.search("Tasso")[0].label == "Via Torquato Tasso"


def test_senza_il_feed_si_cerca_lo_stesso_ma_senza_stazioni(
    config: EngineConfig, search: SearchConfig, tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    with caplog.at_level(logging.WARNING):
        found = directory(config, search, tmp_path).search("Via Torquato Tasso")
    assert found[0].label == "Via Torquato Tasso"
    assert "stazioni" in caplog.text


# --- i file di configurazione --------------------


def test_il_file_vero_dei_luoghi_e_valido_e_ogni_zona_citata_esiste(config: EngineConfig) -> None:
    places = PlacesConfig.from_yaml()
    zones = {zone.id for zone in config.demand.zones}
    assert places.places
    for place in places.places:
        assert place.zone is None or place.zone in zones, place.id


def test_il_file_vero_dei_parametri_e_valido() -> None:
    routing = RoutingConfig.from_yaml()
    assert routing.search.max_candidates == 5 and routing.search.long_street_m == 1000
    assert (
        routing.route.alternative_penalty == 1.5 and routing.route.alternative_max_longer_pct == 50
    )
    assert routing.search.abbreviations["v.le"] == "viale"


@pytest.mark.parametrize(
    "text",
    [
        "{id: a, label: A, zone: z}",  # una zona con un nome suo: il nome è quello della zona
        "{id: a, zone: z, lat: 40.8, lon: 14.2}",  # una zona E un punto
        "{id: a}",  # né l'una né l'altro
        "{id: a, label: A, lat: 40.8}",  # un punto a metà
        "{id: a, lat: 40.8, lon: 14.2}",  # un punto senza etichetta
        "{id: a, lat: 95, lon: 14.2, label: A}",  # latitudine impossibile
        "{id: A, zone: z}",  # id non è uno slug
        "{id: a, zone: z, ciao: 1}",  # campo sconosciuto
    ],
)
def test_luoghi_non_validi(text: str) -> None:
    with pytest.raises(ValidationError):
        PlacesConfig.from_yaml_text(f"places:\n  - {text}")


def test_id_di_luogo_duplicati() -> None:
    with pytest.raises(ValidationError, match="duplicati"):
        PlacesConfig.from_yaml_text("places:\n  - {id: a, zone: z}\n  - {id: a, zone: y}")


def test_un_luogo_con_zona_o_con_punto_si_legge() -> None:
    assert KnownPlace(id="a", zone="z").point is None
    point = KnownPlace(id="a", label="A", lat=40.8, lon=14.2).point
    assert point is not None and (point.lat, point.lon) == (40.8, 14.2)


@pytest.mark.parametrize(
    ("section", "field", "value"),
    [
        ("search", "max_candidates", 0),
        ("search", "long_street_m", 0),
        ("search", "fuzzy_cutoff", 0),
        ("search", "fuzzy_cutoff", 1.5),
        ("search", "crossing_m", -1),
        ("route", "alternative_penalty", 1.0),
        ("route", "alternative_max_overlap_pct", 0),
        ("route", "alternative_max_overlap_pct", 101),
        ("route", "nearby_m", 0),
    ],
)
def test_parametri_non_validi(section: str, field: str, value: float) -> None:
    raw = RoutingConfig.from_yaml().model_dump(mode="json")
    raw[section][field] = value
    with pytest.raises(ValidationError):
        RoutingConfig.model_validate(raw)
