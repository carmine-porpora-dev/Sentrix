import datetime as dt
from collections.abc import Mapping
from dataclasses import replace
from typing import Any

import networkx as nx
import pytest
from shapely.geometry import LineString  # type: ignore[import-untyped]

from app.data.resolvers import edge_key, parse_edge_key
from app.engine import STATIC_MODEL_ASSUMPTION
from app.engine.assign import EdgeLoad, Route
from app.engine.graph import build_road_graph
from app.engine.routing import (
    ClosureRef,
    avoided_closures,
    congested_near_route,
    congested_streets,
    free_flow_costs,
    free_flow_loads,
    free_flow_route,
    plan_routes,
    route_coordinates,
    route_steps,
    window_costs,
    window_of,
)
from app.engine.run import RoadEngine
from app.geo import haversine_m
from app.models.base import Window
from app.models.config import EngineConfig
from app.models.run import AttendanceLevel
from tests.support import HUB, build_star_raw_graph, graph_fingerprint, make_event, make_request

AS_OF = dt.datetime(2026, 11, 9, 12, 0, tzinfo=dt.UTC)

# Un rombo: da 1 a 4 si va per 2 (sopra) o per 3 (sotto); le coordinate sono a Napoli.
POSITIONS = {
    1: (14.2000, 40.8000),
    2: (14.2050, 40.8040),
    3: (14.2050, 40.7960),
    4: (14.2100, 40.8000),
}


def key(u: int, v: int, k: int = 0) -> str:
    return edge_key(u, v, k)


def diamond(top: float = 1.0, bottom: float = 1.2) -> nx.MultiDiGraph:
    """Rombo a doppio senso: gli archi di sopra costano `top` minuti, quelli di sotto `bottom`."""
    graph: nx.MultiDiGraph = nx.MultiDiGraph()
    for node, (lon, lat) in POSITIONS.items():
        graph.add_node(node, x=lon, y=lat)
    for u, v, minutes, name in [
        (1, 2, top, "Via Alta"),
        (2, 4, top, "Via Alta"),
        (1, 3, bottom, "Via Bassa"),
        (3, 4, bottom, "Via Bassa Due"),
    ]:
        for a, b in ((u, v), (v, u)):
            length = float(
                haversine_m(POSITIONS[a][1], POSITIONS[a][0], (POSITIONS[b][1], POSITIONS[b][0]))
            )
            graph.add_edge(
                a, b, key=0, length_m=length, t0_min=minutes, capacity_vph=1000.0, name=name
            )
    return graph


def close(graph: nx.MultiDiGraph, *keys: tuple[int, int]) -> nx.MultiDiGraph:
    """Una copia con gli archi `keys` chiusi (capacità 0), come li lascia `apply_measures`."""
    copy = graph.copy()
    for u, v in keys:
        copy.edges[u, v, 0]["capacity_vph"] = 0.0
    return copy


PLAN = {"penalty": 1.5, "max_longer_pct": 50.0, "max_overlap_pct": 90.0}


def plan(
    graph: nx.MultiDiGraph, loads: Mapping[str, EdgeLoad] | None = None, **changes: float
) -> list[Route]:
    return plan_routes(graph, loads or free_flow_loads(graph), 1, 4, **{**PLAN, **changes})


# --- la fascia di un'ora --------------------


@pytest.mark.parametrize(
    ("at", "window"),
    [
        (dt.time(11, 59), None),
        (dt.time(12, 0), "arrival"),  # l'inizio è incluso
        (dt.time(13, 30), "arrival"),
        (dt.time(14, 59), "arrival"),
        (dt.time(15, 0), None),  # la fine è esclusa
        (dt.time(17, 59), None),
        (dt.time(18, 0), "departure"),
        (dt.time(20, 59), "departure"),
        (dt.time(21, 0), None),
        (dt.time(0, 0), None),
        (dt.time(10, 0), None),
    ],
)
def test_la_fascia_e_quella_dell_evento_con_la_fine_esclusa(
    at: dt.time, window: str | None
) -> None:
    assert window_of(make_event(), at) == window


def test_la_fascia_segue_i_dati_dell_evento_non_un_orario_fisso() -> None:
    event = make_event(
        arrival={"start": "09:00", "end": "10:00", "peak": "09:30"},
        departure={"start": "22:00", "end": "23:30", "peak": "22:30"},
    )
    assert window_of(event, dt.time(9, 30)) == "arrival"
    assert window_of(event, dt.time(13, 30)) is None
    assert window_of(event, dt.time(23, 0)) == "departure"


# --- strada libera --------------------


def test_a_strada_libera_ogni_arco_aperto_ha_il_suo_t0_e_vc_zero() -> None:
    loads = free_flow_loads(diamond())
    assert len(loads) == 8
    one = loads[key(1, 2)]
    assert (one.t_min, one.cost_min, one.vc, one.v_total, one.v_event) == (1.0, 1.0, 0.0, 0.0, 0.0)
    assert one.capacity_vph == 1000.0


def test_gli_archi_chiusi_non_hanno_carico() -> None:
    loads = free_flow_loads(close(diamond(), (1, 2), (2, 1)))
    assert key(1, 2) not in loads and key(2, 1) not in loads and len(loads) == 6


def test_il_fattore_di_percezione_cambia_il_costo_non_il_tempo() -> None:
    graph = diamond()
    graph.edges[1, 2, 0]["perceived_factor"] = 1.2
    one = free_flow_loads(graph)[key(1, 2)]
    assert (one.t_min, one.cost_min) == (1.0, pytest.approx(1.2))


# --- il percorso --------------------


def test_il_percorso_consigliato_e_il_piu_veloce_con_tempo_e_lunghezza_veri() -> None:
    graph = diamond()
    first = plan(graph)[0]
    assert first.edges == (key(1, 2), key(2, 4))
    assert first.time_min == pytest.approx(2.0)
    assert first.length_m == pytest.approx(
        sum(graph.edges[parse_edge_key(k)]["length_m"] for k in first.edges)
    )


def test_l_alternativa_penalizza_gli_archi_del_primo_ma_riporta_il_tempo_vero() -> None:
    first, second = plan(diamond())
    assert second.edges == (key(1, 3), key(3, 4))
    assert second.time_min == pytest.approx(2.4)  # 1,2 + 1,2: non il costo penalizzato
    assert set(first.edges).isdisjoint(second.edges)


def test_l_alternativa_che_dura_piu_del_50_per_cento_si_scarta() -> None:
    """Con la penalità di 1,5 l'alternativa non supera mai +50 % (costa al più 1,5 volte il
    primo): la regola protegge chi sceglie una penalità più alta."""
    graph = diamond(top=1.0, bottom=2.1)  # sotto: 4,2 minuti contro 2,0
    assert len(plan(graph, penalty=3.0)) == 1  # +110 %: scartata
    assert len(plan(graph, penalty=3.0, max_longer_pct=150.0)) == 2


def test_senza_un_altro_cammino_non_c_e_alternativa() -> None:
    graph: nx.MultiDiGraph = nx.MultiDiGraph()
    for node, (lon, lat) in POSITIONS.items():
        graph.add_node(node, x=lon, y=lat)
    for u, v in ((1, 2), (2, 4)):
        graph.add_edge(u, v, key=0, length_m=100.0, t0_min=1.0, capacity_vph=1000.0, name="Via")
    assert len(plan(graph)) == 1


def test_l_alternativa_che_ripete_quasi_tutto_il_primo_si_scarta() -> None:
    """Un cammino che cambia un tratto di 68 m non è un'alternativa: per l'utente è lo stesso."""
    graph: nx.MultiDiGraph = nx.MultiDiGraph()
    for node in range(1, 6):
        graph.add_node(node, x=14.2 + node * 0.001, y=40.8)

    def add(u: int, v: int, length: float, minutes: float) -> None:
        graph.add_edge(
            u, v, key=0, length_m=length, t0_min=minutes, capacity_vph=1000.0, name="Via"
        )

    add(1, 2, 3000.0, 3.0)  # il lungo tratto comune
    add(2, 3, 50.0, 0.05)  # le due varianti di 50-68 m
    add(2, 4, 68.0, 0.07)
    add(3, 5, 10.0, 0.01)
    add(4, 5, 10.0, 0.01)
    first = plan_routes(graph, free_flow_loads(graph), 1, 5, **PLAN)
    assert len(first) == 1  # sovrapposizione ~98 %
    both = plan_routes(graph, free_flow_loads(graph), 1, 5, **{**PLAN, "max_overlap_pct": 100.0})
    assert len(both) == 2


def test_una_chiusura_allunga_il_percorso() -> None:
    graph = diamond()
    open_route = plan(graph)[0]
    shut = close(graph, (1, 2), (2, 1))  # chiusa la strada di sopra
    detour = plan(shut)[0]
    assert open_route.edges == (key(1, 2), key(2, 4))
    assert detour.edges == (key(1, 3), key(3, 4))
    assert detour.time_min > open_route.time_min
    assert len(plan(shut)) == 1  # non resta nessun altro cammino


def test_con_il_traffico_il_percorso_cambia_e_il_tempo_e_quello_dei_carichi() -> None:
    graph = diamond()
    loads = dict(free_flow_loads(graph))
    loads[key(1, 2)] = replace(loads[key(1, 2)], t_min=3.0, cost_min=3.0, vc=1.4)  # sopra intasato
    first = plan(graph, loads)[0]
    assert first.edges == (key(1, 3), key(3, 4))
    assert first.time_min == pytest.approx(2.4)


def test_nessun_cammino_se_la_destinazione_non_si_raggiunge() -> None:
    graph = close(diamond(), (1, 2), (1, 3))  # da 1 non si esce
    assert plan(graph) == []


def test_il_calcolo_e_deterministico_e_a_parita_di_costo_vince_l_arco_minore() -> None:
    graph = diamond(top=1.0, bottom=1.0)  # due cammini identici
    results = [plan(graph) for _ in range(3)]
    assert results[0] == results[1] == results[2]
    assert results[0][0].edges == (key(1, 2), key(2, 4))  # quello con la chiave minore


def test_il_calcolo_non_modifica_la_rete() -> None:
    graph = diamond()
    before = graph_fingerprint(graph)
    plan(graph)
    free_flow_route(graph, 1, 4)
    assert graph_fingerprint(graph) == before


def test_il_percorso_a_strada_libera_ignora_le_chiusure_che_la_rete_non_ha() -> None:
    base = diamond()
    shut = close(base, (1, 2), (2, 1))
    assert free_flow_route(base, 1, 4) is not None
    assert free_flow_route(base, 1, 4).edges == (key(1, 2), key(2, 4))  # type: ignore[union-attr]
    assert free_flow_route(shut, 1, 4).edges == (key(1, 3), key(3, 4))  # type: ignore[union-attr]


# --- tratti e linea --------------------


def named(graph: nx.MultiDiGraph, names: dict[tuple[int, int], object]) -> nx.MultiDiGraph:
    copy = graph.copy()
    for (u, v), name in names.items():
        copy.edges[u, v, 0]["name"] = name
    return copy


def test_gli_archi_consecutivi_con_lo_stesso_nome_si_uniscono() -> None:
    graph = diamond()
    steps = route_steps(graph, [key(1, 2), key(2, 4)])
    assert [s.street_name for s in steps] == ["Via Alta"]
    assert steps[0].length_m == pytest.approx(
        graph.edges[1, 2, 0]["length_m"] + graph.edges[2, 4, 0]["length_m"]
    )


def test_nomi_diversi_restano_tratti_diversi_e_senza_nome_si_uniscono_tra_loro() -> None:
    graph = named(diamond(), {(1, 3): "Via Bassa", (3, 4): None, (2, 4): None, (1, 2): None})
    assert [s.street_name for s in route_steps(graph, [key(1, 3), key(3, 4)])] == [
        "Via Bassa",
        None,
    ]
    (merged,) = route_steps(graph, [key(1, 2), key(2, 4)])
    assert merged.street_name is None
    assert merged.length_m == pytest.approx(
        graph.edges[1, 2, 0]["length_m"] + graph.edges[2, 4, 0]["length_m"]
    )


def test_un_nome_che_non_e_testo_o_e_vuoto_vale_senza_nome() -> None:
    graph = named(diamond(), {(1, 2): 42, (2, 4): "   "})
    assert [s.street_name for s in route_steps(graph, [key(1, 2), key(2, 4)])] == [None]


def test_la_linea_unisce_gli_archi_senza_ripetere_il_punto_di_giunzione() -> None:
    graph = diamond()
    line = route_coordinates(graph, [key(1, 2), key(2, 4)])
    assert line == [[14.2, 40.8], [14.205, 40.804], [14.21, 40.8]]


def test_un_arco_curvo_segue_la_sua_geometria() -> None:
    graph = diamond()
    graph.edges[1, 2, 0]["geometry"] = LineString(
        [(14.2, 40.8), (14.202, 40.803), (14.205, 40.804)]
    )
    line = route_coordinates(graph, [key(1, 2), key(2, 4)])
    assert line == [[14.2, 40.8], [14.202, 40.803], [14.205, 40.804], [14.21, 40.8]]


# --- strade sature --------------------


def with_vc(graph: nx.MultiDiGraph, **vc: float) -> dict[str, EdgeLoad]:
    loads = dict(free_flow_loads(graph))
    for text, value in vc.items():
        u, v = (int(part) for part in text.removeprefix("e").split("_"))
        loads[key(u, v)] = replace(loads[key(u, v)], vc=value)
    return loads


def test_le_strade_sature_si_raggruppano_per_nome_con_il_carico_piu_alto() -> None:
    graph = named(diamond(), {(1, 2): "Via Alta", (2, 4): "Via Alta", (1, 3): None})
    loads = with_vc(graph, e1_2=1.3, e2_4=0.95, e1_3=2.0, e3_4=0.5)
    assert congested_streets(graph, loads, [key(1, 2), key(2, 4), key(1, 3), key(3, 4)], 0.9) == {
        "Via Alta": 1.3  # il più alto dei due archi; l'arco senza nome non si elenca
    }


def test_la_soglia_e_stretta_0_9_non_e_satura() -> None:
    graph = diamond()
    loads = with_vc(graph, e1_2=0.9, e2_4=0.9001)
    assert congested_streets(graph, loads, [key(1, 2), key(2, 4)], 0.9) == {"Via Alta": 0.9001}


def test_vicino_al_percorso_conta_la_distanza_dalla_linea_non_dai_vertici() -> None:
    """Il percorso è un segmento lungo ~1 km con soli due vertici: un arco a 100 m dal suo
    centro è vicino, anche se dista 500 m da tutti e due i vertici."""
    graph: nx.MultiDiGraph = nx.MultiDiGraph()
    pts = {
        1: (14.2000, 40.8000),
        2: (14.2118, 40.8000),
        3: (14.2059, 40.8009),
        4: (14.2059, 40.8040),
        5: (14.2059, 40.8100),
    }
    for node, (lon, lat) in pts.items():
        graph.add_node(node, x=lon, y=lat)

    def add(u: int, v: int, name: str) -> None:
        graph.add_edge(u, v, key=0, length_m=100.0, t0_min=1.0, capacity_vph=1000.0, name=name)

    add(1, 2, "Via Percorso")
    add(3, 4, "Via Vicina")  # il punto medio è a ~272 m dalla linea, a ~566 m da ogni vertice
    add(4, 5, "Via Lontana")
    loads = with_vc(graph, e1_2=1.5, e3_4=1.5, e4_5=1.5)
    near = congested_near_route(graph, loads, [key(1, 2)], 0.9, near_m=300.0)
    assert "Via Percorso" not in near  # è sul percorso
    assert near == {"Via Vicina": 1.5}  # e «Via Lontana» (oltre 600 m) no


def test_vicino_non_ripete_le_strade_del_percorso_ne_quelle_sotto_soglia() -> None:
    graph = diamond()
    loads = with_vc(graph, e1_2=1.5, e1_3=0.5, e3_4=1.2)
    near = congested_near_route(graph, loads, [key(1, 2), key(2, 4)], 0.9, near_m=10_000.0)
    assert near == {"Via Bassa Due": 1.2}


def test_senza_percorso_o_senza_archi_saturi_il_vicino_e_vuoto() -> None:
    graph = diamond()
    assert congested_near_route(graph, free_flow_loads(graph), [key(1, 2)], 0.9, 1000.0) == {}
    assert congested_near_route(graph, with_vc(graph, e1_3=2.0), [], 0.9, 1000.0) == {}


# --- chiusure evitate --------------------


def closure(label: str, *edges: tuple[int, int], source: str | None = "ordinanza") -> ClosureRef:
    return ClosureRef(label, source, tuple(key(u, v) for u, v in edges))


def test_una_chiusura_sul_percorso_a_strada_libera_che_si_evita_e_evitata() -> None:
    base = diamond()
    free = free_flow_route(base, 1, 4)  # passa per 1-2-4
    detour = Route(edges=(key(1, 3), key(3, 4)), time_min=2.4, length_m=1.0)
    found = avoided_closures(
        base, [closure("Via Alta chiusa", (1, 2), (2, 1))], free, detour, 150.0
    )
    assert [c.label for c in found] == ["Via Alta chiusa"]
    assert found[0].source_ref == "ordinanza"


def test_una_chiusura_lontana_dal_percorso_a_strada_libera_non_conta() -> None:
    base = diamond()
    free = free_flow_route(base, 1, 4)  # passa per 1-2-4
    assert free is not None
    far = closure("Via Bassa chiusa", (1, 3), (3, 1))  # a qualche centinaio di metri
    assert avoided_closures(base, [far], free, free, 150.0) == []
    assert avoided_closures(base, [far], free, free, 5000.0) == [far]  # «vicino» è un parametro


def test_una_chiusura_che_il_percorso_attraversa_non_e_evitata() -> None:
    """Capacità ridotta, non chiusa: gli archi restano nel grafo e il percorso può usarli."""
    base = diamond()
    free = free_flow_route(base, 1, 4)
    route = Route(edges=free.edges, time_min=2.0, length_m=1.0)  # type: ignore[union-attr]
    assert avoided_closures(base, [closure("ridotta", (1, 2))], free, route, 150.0) == []


def test_senza_percorso_a_strada_libera_non_c_e_nulla_da_evitare() -> None:
    base = diamond()
    route = Route(edges=(key(1, 3),), time_min=1.0, length_m=1.0)
    assert avoided_closures(base, [closure("x", (1, 2))], None, route, 150.0) == []
    assert avoided_closures(base, [closure("x")], free_flow_route(base, 1, 4), route, 150.0) == []


# --- i costi di una fascia: stessi dell'analisi --------------------


@pytest.fixture(scope="module")
def config() -> EngineConfig:
    return EngineConfig.from_yaml()


@pytest.fixture(scope="module")
def star(config: EngineConfig) -> nx.MultiDiGraph:
    return build_road_graph(build_star_raw_graph(config), config)


def spoke(star: nx.MultiDiGraph, index: int = 0) -> tuple[str, int]:
    """Un arco uscente dal centro della stella e il nodo in cui arriva."""
    node = sorted(v for _, v in star.out_edges(HUB))[index]
    return edge_key(HUB, node, 0), node


def layer_of(star: nx.MultiDiGraph, config: EngineConfig, **run: Any) -> dict[str, dict[str, Any]]:
    """I layer `edges_vc` di `RoadEngine.run`: arco → proprietà."""
    result = RoadEngine(star, config).run(id_prefix=("t", "it0"), as_of=AS_OF, **run).result
    return {
        str(f.properties["edge_key"]): dict(f.properties)
        for f in result.metrics.layers["edges_vc"].features
    }


@pytest.mark.parametrize("window", ["arrival", "departure"])
@pytest.mark.parametrize("level", ["low", "mid", "high"])
def test_i_carichi_coincidono_con_quelli_che_il_motore_mette_nei_layer(
    star: nx.MultiDiGraph, config: EngineConfig, window: Window, level: AttendanceLevel
) -> None:
    """`window_costs` rifà i passi di `RoadEngine.run`: se `run` cambia e questa no, qui si vede."""
    event = make_event()
    layer = layer_of(star, config, event=event, level=level, window=window)
    costs = window_costs(star, event, level, window, [], config)
    assert layer  # il caso prova qualcosa
    for edge, properties in layer.items():
        assert costs.loads[edge].vc == properties["vc"], edge


def test_con_misure_e_chiusure_i_carichi_coincidono_ancora(
    star: nx.MultiDiGraph, config: EngineConfig
) -> None:
    closed_edge, _ = spoke(star, 0)
    _, other = spoke(star, 1)
    event = make_event(closures=[{"label": "Raggio chiuso", "edge_keys": [closed_edge]}])
    measures = [
        make_request(
            f"act_{n}",
            type="traffic_post",
            target=str(other),
            window=window,
            iteration=1,
            state="ACCEPTED",
        )
        for n, window in enumerate(("arrival", "departure"), start=1)
    ]
    windows: tuple[Window, ...] = ("arrival", "departure")
    for window in windows:
        layer = layer_of(star, config, event=event, level="mid", window=window, measures=measures)
        costs = window_costs(star, event, "mid", window, measures, config)
        assert {edge for edge, props in layer.items() if props["closed"]} == {closed_edge}
        assert closed_edge not in costs.loads  # chiuso: fuori dai carichi e dall'instradamento
        for edge, props in layer.items():
            if not props["closed"]:
                assert costs.loads[edge].vc == props["vc"]


def test_window_costs_non_modifica_la_rete_e_ripetuto_da_lo_stesso_risultato(
    star: nx.MultiDiGraph, config: EngineConfig
) -> None:
    before = graph_fingerprint(star)
    one = window_costs(star, make_event(), "mid", "arrival", [], config)
    two = window_costs(star, make_event(), "mid", "arrival", [], config)
    assert graph_fingerprint(star) == before
    assert dict(one.loads) == dict(two.loads)
    assert one.simulated is True and STATIC_MODEL_ASSUMPTION in one.assumptions


def test_le_assunzioni_non_hanno_doppioni_e_dicono_le_chiusure(
    star: nx.MultiDiGraph, config: EngineConfig
) -> None:
    edge, _ = spoke(star)
    event = make_event(closures=[{"label": "Raggio chiuso", "edge_keys": [edge]}])
    costs = window_costs(star, event, "mid", "arrival", [], config)
    assert len(costs.assumptions) == len(set(costs.assumptions))
    assert any("chiusure dell'evento" in a for a in costs.assumptions)


def test_fuori_fascia_i_costi_sono_a_strada_libera_con_le_sole_chiusure_dell_evento(
    star: nx.MultiDiGraph, config: EngineConfig
) -> None:
    edge, _ = spoke(star)
    event = make_event(closures=[{"label": "Raggio chiuso", "edge_keys": [edge]}])
    costs = free_flow_costs(star, event, config)
    assert costs.simulated is False
    assert edge not in costs.loads and len(costs.loads) == star.number_of_edges() - 1
    assert all(load.vc == 0.0 and load.t_min == load.cost_min for load in costs.loads.values())
    assert any("strada libera" in a for a in costs.assumptions)
    assert STATIC_MODEL_ASSUMPTION in costs.assumptions
