import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.data.map_data import MapData
from app.data.paths import DataPaths
from app.data.places import PlaceDirectory
from app.data.resolvers import edge_coordinates, parse_edge_key, resolve_closure
from app.data.route_service import RouteError, RouteService
from app.db.repository import Repository
from app.geo import COORD_DECIMALS, haversine_m
from app.models.agents_config import AgentsConfig
from app.models.places import PlaceCandidate, PlacesConfig
from app.models.routing import RouteRequest, RouteResponse, RoutingConfig
from scripts.common import add_data_dir_arg, atomic_write_text, default_data_dir
from scripts.resolve_seeds import (
    MAPLIBRE_BASE,
    MAPLIBRE_CSS_SRI,
    MAPLIBRE_JS_SRI,
    script_safe_json,
)

DESCRIPTION = (
    "Pagina di verifica dei percorsi dell'assistente (docs/spec/10-assistant.md, cancello A1): "
    "esegue le domande di verifica sul servizio vero e scrive route_check.html in DATA_DIR/report/"
)
HTML_NAME = "route_check.html"
GEOJSON_NAME = "route_check.geojson"
PAGE = Path(__file__).with_name("route_check_page.html").read_text(encoding="utf-8")
MAP_BOUNDS = [14.14, 40.79, 14.32, 40.90]  # Napoli: ovest, sud, est, nord


@dataclass(frozen=True)
class Question:
    number: str  # il numero in 10 §7
    text: str
    start: str  # come lo cercherebbe l'assistente
    end: str
    time: str


# Le domande di verifica del cancello A1 (10 §8): cambiano le parole, non il calcolo.
QUESTIONS = (
    Question(
        "1",
        "Devo prendere mio figlio a scuola in via Tasso, parto da piazza Garibaldi alle 13:30",
        "piazza Garibaldi",
        "via Tasso",
        "13:30",
    ),
    Question(
        "1 bis",
        "La stessa, con un incrocio al posto della strada lunga",
        "piazza Garibaldi",
        "via Tasso angolo via Aniello Falcone",
        "13:30",
    ),
    Question(
        "2",
        "Alle 16:45 devo andare dalla stazione Centrale a Mergellina in auto: cosa evito?",
        "stazione Centrale",
        "Mergellina",
        "16:45",
    ),
    Question(
        "6",
        "I'm at Molo Beverello, I need to drive to Fuorigrotta at 1:45 pm. Which way?",
        "Molo Beverello",
        "Fuorigrotta",
        "13:45",
    ),
    Question(
        "7",
        "Devo andare al Vomero da piazza Plebiscito alle 10: ci sono problemi? (fuori fascia)",
        "piazza Plebiscito",
        "Vomero",
        "10:00",
    ),
)


def _line(coordinates: list[list[float]], **properties: Any) -> dict[str, Any]:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coordinates},
        "properties": properties,
    }


def _point(lon: float, lat: float, **properties: Any) -> dict[str, Any]:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": properties,
    }


def summarize(
    question: Question, start: PlaceCandidate, end: PlaceCandidate, answer: RouteResponse
) -> str:
    main = answer.routes[0]
    lines = [
        f"Domanda {question.number}: {start.label} → {end.label} alle {question.time} "
        f"(fascia {answer.context.window})",
        f"  consigliato: {main.duration.value} {main.duration.unit} [{main.duration.kind}], "
        f"{main.length.value} {main.length.unit}",
    ]
    if len(answer.routes) > 1:
        other = answer.routes[1]
        lines.append(f"  alternativa: {other.duration.value} {other.duration.unit}, "
                     f"{other.length.value} {other.length.unit}")  # fmt: skip
    avoided = ", ".join(c.label for c in answer.avoided_closures) or "nessuna"
    crowded = ", ".join(f"{s.street_name} {s.vc.value}" for s in answer.congested_on_route)
    lines.append(f"  chiusure evitate: {avoided}")
    lines.append(f"  sature sul percorso: {crowded or 'nessuna'}")
    if end.long_street or start.long_street:
        lines.append("  ATTENZIONE: una strada lunga: l'assistente chiederà un punto più preciso")
    return "\n".join(lines)


def build(event_id: str, data_dir: Path) -> tuple[dict[str, Any], list[str], bool]:
    """I dati della pagina, il testo di riepilogo e se ogni domanda ha avuto una risposta."""
    paths = DataPaths(data_dir)
    repo = Repository(paths.database)
    map_data = MapData(paths)
    routing = RoutingConfig.from_yaml()
    known = PlacesConfig.from_yaml()
    labels = dict(AgentsConfig.from_yaml().labels.route_classes)
    directory = PlaceDirectory(map_data, known, routing.search, labels)
    routes = RouteService(repo, map_data, routing.route)
    graph = map_data.graph()

    network = [
        _line(edge_coordinates(graph, (u, v, k), COORD_DECIMALS))
        for u, v, k in graph.edges(keys=True)
    ]
    threshold = map_data.config.metrics.vc_critical_threshold  # la soglia di engine.yaml
    closures: list[dict[str, Any]] = []
    saturated: list[dict[str, Any]] = []
    done = [r for r in repo.list_runs(event_id) if r.state == "DONE"]
    if done:
        run = done[0]
        event = repo.get_event_revision(run.event_id, run.event_revision)
        assert event is not None
        for closure in event.closures:
            for key in resolve_closure(closure, graph):
                coordinates = edge_coordinates(graph, parse_edge_key(key), COORD_DECIMALS)
                closures.append(_line(coordinates, label=closure.label))
        layer = repo.get_layer(run.id, run.iteration, "edges_vc")
        for feature in layer.features if layer else ():
            vc = feature.properties.get("vc")
            if isinstance(vc, int | float) and vc > threshold and feature.geometry:
                saturated.append(
                    {
                        "type": "Feature",
                        "geometry": feature.geometry,
                        "properties": {
                            "window": feature.properties.get("window"),
                            "vc": vc,
                            "name": feature.properties.get("name"),
                        },
                    }
                )

    ok, texts, results = True, [], []
    for question in QUESTIONS:
        start, end = directory.search(question.start), directory.search(question.end)
        if not start or not end:
            ok = False
            texts.append(f"Domanda {question.number}: luogo non trovato")
            continue
        body = {
            "event_id": event_id,
            "from_node": start[0].node_id,
            "to_node": end[0].node_id,
            "time": question.time,
        }
        try:
            answer = routes.plan(RouteRequest.model_validate(body))
        except RouteError as error:
            ok = False
            texts.append(f"Domanda {question.number}: {error.code}: {error.message}")
            continue
        texts.append(summarize(question, start[0], end[0], answer))
        results.append(
            {
                "number": question.number,
                "text": question.text,
                "time": question.time,
                "window": answer.context.window,
                "places": [
                    {
                        "role": role,
                        "label": c[0].label,
                        "long_street": c[0].long_street,
                        "others": [x.label for x in c[1:]],
                    }
                    for role, c in (("partenza", start), ("arrivo", end))
                ],  # fmt: skip
                "points": [
                    _point(c[0].lon, c[0].lat, role=role, label=c[0].label)
                    for role, c in (("partenza", start), ("arrivo", end))
                ],
                "routes": [
                    {
                        "role": role,
                        "duration": f"{r.duration.value} {r.duration.unit} · {r.duration.kind}",
                        "length": f"{r.length.value} {r.length.unit}",
                        "steps": [
                            f"{s.street_name or '(senza nome)'} — {round(s.length_m)} m"
                            for s in r.steps
                        ],
                        "geometry": r.geometry,
                    }
                    for role, r in zip(("consigliato", "alternativa"), answer.routes, strict=False)
                ],
                "avoided": [c.label for c in answer.avoided_closures],
                "on_route": [
                    f"{s.street_name} · v/c {s.vc.value}" for s in answer.congested_on_route
                ],
                "nearby": [f"{s.street_name} · v/c {s.vc.value}" for s in answer.congested_nearby],
            }
        )

    index = directory.index()
    zones = {zone.id: zone.centroid for zone in map_data.config.demand.zones}
    entries = {entry.id: entry for entry in index.entries()}
    places = []
    for place in known.places:
        entry = entries.get(f"place:{place.id}")
        asked = zones.get(place.zone) if place.zone else place.point
        if entry is None or asked is None:
            continue
        lat, lon = float(graph.nodes[entry.node]["y"]), float(graph.nodes[entry.node]["x"])
        places.append(
            _point(
                lon,
                lat,
                role="luogo noto",
                label=entry.label,
                id=place.id,
                aliases=", ".join(place.aliases),
                richiesto=f"{asked.lat:.5f}, {asked.lon:.5f}",
                distanza_dal_nodo_m=round(float(haversine_m(asked.lat, asked.lon, (lat, lon)))),
            )
        )
    data = {
        "event": event_id,
        "bounds": MAP_BOUNDS,
        "network": {"type": "FeatureCollection", "features": network},
        "closures": {"type": "FeatureCollection", "features": closures},
        "saturated": {"type": "FeatureCollection", "features": saturated},
        "places": {"type": "FeatureCollection", "features": places},
        "questions": results,
        "dictionary": len(index),
    }
    return data, texts, ok


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=DESCRIPTION)
    add_data_dir_arg(parser)
    parser.add_argument("--event", required=True, help="l'evento di cui verificare i percorsi")
    args = parser.parse_args(argv)
    data_dir = Path(args.data_dir) if args.data_dir else default_data_dir()
    data, texts, ok = build(args.event, data_dir)
    report = data_dir / "report"
    report.mkdir(parents=True, exist_ok=True)
    points = [f for q in data["questions"] for f in q["points"]] + data["places"]["features"]
    atomic_write_text(
        report / GEOJSON_NAME,
        json.dumps({"type": "FeatureCollection", "features": points}, ensure_ascii=False),
    )
    page = (
        PAGE.replace("__MAPLIBRE_CSS__", f"{MAPLIBRE_BASE}/maplibre-gl.css")
        .replace("__MAPLIBRE_CSS_SRI__", MAPLIBRE_CSS_SRI)
        .replace("__MAPLIBRE_JS__", f"{MAPLIBRE_BASE}/maplibre-gl.js")
        .replace("__MAPLIBRE_JS_SRI__", MAPLIBRE_JS_SRI)
        .replace("__DATA__", script_safe_json(data))
    )
    atomic_write_text(report / HTML_NAME, page)
    print("\n".join(texts))
    print(f"\nDizionario: {data['dictionary']} luoghi. Pagina di verifica: {report / HTML_NAME}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
